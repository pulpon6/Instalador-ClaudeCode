#!/bin/bash
# ============================================================================
#  Instalador de entorno Claude (macOS)
#  2026-08-28
#
#  Uso:
#    ./instalar-mac.command                  instala el perfil completo
#    ./instalar-mac.command --perfil basico  solo lo esencial (sin rtk ni gstack)
#    ./instalar-mac.command --diagnostico    solo revisa, no instala nada
#    ./instalar-mac.command --dry-run        muestra qué haría, sin hacerlo
#    ./instalar-mac.command --si             no pide confirmación
#
#  El instalador NUNCA instala a ciegas: comprueba cada pieza antes y salta
#  lo que ya esté presente.
# ============================================================================

set -uo pipefail

VERSION_INSTALADOR="2.3.0"
DIR_SCRIPT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DIR_BASE="$(cd "$DIR_SCRIPT/.." && pwd)"
ARCHIVO_CARPETAS="$DIR_BASE/config/carpetas.txt"

PERFIL="completo"
MODO_DIAGNOSTICO=0
DRY_RUN=0
SIN_PREGUNTAR=0

while [ $# -gt 0 ]; do
  case "$1" in
    --perfil) PERFIL="${2:-completo}"; shift 2 ;;
    --diagnostico) MODO_DIAGNOSTICO=1; shift ;;
    --dry-run) DRY_RUN=1; shift ;;
    --si|--yes|-y) SIN_PREGUNTAR=1; shift ;;
    -h|--help) sed -n '2,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "Opción desconocida: $1"; exit 2 ;;
  esac
done

# ---------------------------------------------------------------- registro ---
DIR_LOG="$HOME/Library/Logs/instalador-claude"
mkdir -p "$DIR_LOG"
LOG="$DIR_LOG/instalacion-$(date +%Y%m%d-%H%M%S).log"
REPORTE="$DIR_LOG/reporte-$(date +%Y%m%d-%H%M%S).html"

registrar() { printf '%s  %s\n' "$(date +%H:%M:%S)" "$*" >> "$LOG"; }

R=$'\033[0m'; NEG=$'\033[1m'; VER=$'\033[32m'; AMA=$'\033[33m'; ROJ=$'\033[31m'; GRI=$'\033[90m'

titulo()  { printf '\n%s%s%s\n%s\n' "$NEG" "$1" "$R" "$(printf '─%.0s' $(seq 1 ${#1}))"; registrar "== $1"; }
ok()      { printf '  %s✓%s %s\n' "$VER" "$R" "$1"; registrar "OK    $1"; }
aviso()   { printf '  %s!%s %s\n' "$AMA" "$R" "$1"; registrar "AVISO $1"; }
ERRORES=0
error()   { ERRORES=$((ERRORES+1)); printf '  %s✗%s %s\n' "$ROJ" "$R" "$1"; registrar "ERROR $1"; }
info()    { printf '  %s·%s %s\n' "$GRI" "$R" "$1"; registrar "info  $1"; }
paso()    { printf '  %s→%s %s\n' "$NEG" "$R" "$1"; registrar "PASO  $1"; }

# Resultados para el reporte final: "estado|pieza|detalle"
RESULTADOS=()
anotar() { RESULTADOS+=("$1|$2|$3"); }

ejecutar() {
  # ejecutar "descripción" comando...
  local desc="$1"; shift
  if [ "$DRY_RUN" = "1" ]; then
    info "[simulación] $desc"
    return 0
  fi
  registrar "CMD   $*"
  if "$@" >> "$LOG" 2>&1; then
    return 0
  else
    return 1
  fi
}

# --------------------------------------------------------------- contexto ---
export PATH="$HOME/.local/bin:$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

ARQ="$(uname -m)"
VERSION_MACOS="$(sw_vers -productVersion 2>/dev/null || echo desconocida)"
USUARIO="$(id -un)"

# Con sudo, TODO iría a parar a /var/root en vez de al perfil del empleado, y
# además macOS bloquea el modo bypassPermissions cuando Claude corre como root.
if [ "$(id -u)" = "0" ]; then
  printf '\n%s✗ No ejecutes este instalador con sudo ni como root.%s\n\n' "$ROJ" "$R"
  printf 'Todo se instalaría en el perfil del administrador (/var/root) y no en el tuyo:\n'
  printf 'te quedarías sin Claude, sin carpetas y sin configuración, y el reporte diría\n'
  printf 'que salió bien.\n\n'
  printf 'Cerrá esta ventana y abrí el instalador con doble clic normal.\n\n'
  printf 'Si lo que querías era instalar Google Drive, el instalador te va a pedir la\n'
  printf 'contraseña él solo, cuando le haga falta.\n\n'
  exit 1
fi

TIENE_ADMIN=0
if id -Gn "$USUARIO" 2>/dev/null | tr ' ' '\n' | grep -qx admin; then TIENE_ADMIN=1; fi

clear
cat <<BANNER
${NEG}Instalador de entorno Claude${R}
${GRI}versión $VERSION_INSTALADOR (beta) · macOS $VERSION_MACOS · $ARQ · usuario $USUARIO${R}
BANNER
[ "$DRY_RUN" = "1" ] && printf '\n%s MODO SIMULACIÓN: no se va a modificar nada. %s\n' "$AMA" "$R"

registrar "instalador $VERSION_INSTALADOR · macOS $VERSION_MACOS · $ARQ · perfil $PERFIL"

# ============================================================== DIAGNÓSTICO ==
titulo "1. Diagnóstico: qué hay ya instalado"

hay() { command -v "$1" >/dev/null 2>&1; }

# La configuración de Claude se fusiona con python3. En un Mac limpio puede no
# haberlo: /usr/bin/python3 es un stub que abre la ventana de Apple. Si uv ya
# está instalado, uv trae su propio Python y sirve igual.
PYTHON=""
asegurar_python() {
  [ -n "$PYTHON" ] && return 0
  if python3 -c 'import json' >/dev/null 2>&1; then PYTHON="python3"; return 0; fi
  if hay uv; then
    if uv python install >>"$LOG" 2>&1 && uv run python -c 'import json' >/dev/null 2>&1; then
      PYTHON="uv run python"; registrar "python via uv"; return 0
    fi
  fi
  return 1
}

# Cada pieza: nombre corto -> etiqueta, estado (presente/ausente), detalle
# macOS trae bash 3.2: no hay arrays asociativos. Se usan variables dinámicas.
estado_de()  { eval "printf '%s' \"\${ESTADO_$1:-0}\""; }
detalle_de() { eval "printf '%s' \"\${DETALLE_$1:-}\""; }

revisar() { # revisar clave "Etiqueta" "detalle si está" presente(0/1)
  eval "ESTADO_$1='$4'"
  eval "DETALLE_$1=\$3"
  if [ "$4" = "1" ]; then ok "$2 — $3"; else info "$2 — no instalado"; fi
}

# -- dependencias base
if hay git; then revisar git "git" "$(git --version 2>/dev/null | awk '{print $3}')" 1
else revisar git "git" "" 0; fi

if hay uv; then revisar uv "uv" "$(uv --version 2>/dev/null | awk '{print $2}')" 1
else revisar uv "uv" "" 0; fi

if hay bun; then revisar bun "bun" "$(bun --version 2>/dev/null)" 1
else revisar bun "bun" "" 0; fi

if hay node; then revisar node "Node.js" "$(node --version 2>/dev/null)" 1
else revisar node "Node.js" "" 0; fi

# -- Claude Code
if hay claude; then revisar claude "Claude Code" "$(claude --version 2>/dev/null | awk '{print $1}')" 1
else revisar claude "Claude Code" "" 0; fi

# -- Claude escritorio
if [ -d "/Applications/Claude.app" ]; then
  revisar claude_app "Claude para escritorio" "instalada" 1
else revisar claude_app "Claude para escritorio" "" 0; fi

# -- rtk
if hay rtk; then revisar rtk "rtk" "$(rtk --version 2>/dev/null | awk '{print $2}')" 1
else revisar rtk "rtk" "" 0; fi

# -- superpowers
# OJO: NO grepear settings.json. La propia plantilla settings-base.json escribe
# 'superpowers@claude-plugins-official' ahí, así que desde la segunda ejecución
# daría "activo" estuviera instalado o no. El estado real vive en
# installed_plugins.json.
AJUSTES="$HOME/.claude/settings.json"
PLUGINS_JSON="$HOME/.claude/plugins/installed_plugins.json"
hay_superpowers() { [ -f "$PLUGINS_JSON" ] && grep -q 'superpowers@' "$PLUGINS_JSON" 2>/dev/null; }
if hay_superpowers; then
  revisar superpowers "Plugin superpowers" "instalado" 1
else revisar superpowers "Plugin superpowers" "" 0; fi

# -- caveman (mismo criterio: installed_plugins.json)
hay_caveman() { [ -f "$PLUGINS_JSON" ] && grep -q 'caveman@' "$PLUGINS_JSON" 2>/dev/null; }
if hay_caveman; then
  revisar caveman "Plugin caveman" "instalado" 1
else revisar caveman "Plugin caveman" "" 0; fi

# -- gstack
# OJO: VERSION está versionado en el repo y existe apenas termina el git clone.
# Por sí solo no distingue una instalación completa de un clone a medias: hace
# falta también la marca que deja el setup al terminar.
GSTACK_DIR="$HOME/.claude/skills/gstack"
MARCA_GSTACK="$HOME/.gstack/.last-setup-version"
if [ -f "$GSTACK_DIR/VERSION" ] && [ -f "$MARCA_GSTACK" ]; then
  revisar gstack "gstack" "$(cat "$GSTACK_DIR/VERSION" 2>/dev/null)" 1
else revisar gstack "gstack" "" 0; fi

# -- markitdown
if hay markitdown; then revisar markitdown "markitdown" "$(markitdown --version 2>/dev/null | awk '{print $2}')" 1
else revisar markitdown "markitdown" "" 0; fi

# -- Google Drive
if [ -d "/Applications/Google Drive.app" ]; then
  revisar gdrive "Google Drive" "instalado" 1
else revisar gdrive "Google Drive" "" 0; fi

# -- carpetas
CARPETAS_FALTAN=0
CARPETAS_TOTAL=0
if [ -f "$ARCHIVO_CARPETAS" ]; then
  while IFS= read -r linea; do
    linea="${linea%%$'\r'}"
    case "$linea" in ''|'#'*) continue ;; esac
    ruta="${linea%%|*}"; ruta="$(echo "$ruta" | sed 's/[[:space:]]*$//')"
    CARPETAS_TOTAL=$((CARPETAS_TOTAL+1))
    [ -d "$HOME/Documents/$ruta" ] || CARPETAS_FALTAN=$((CARPETAS_FALTAN+1))
  done < "$ARCHIVO_CARPETAS"
  if [ "$CARPETAS_FALTAN" = "0" ] && [ "$CARPETAS_TOTAL" -gt 0 ]; then
    revisar carpetas "Estructura de carpetas" "$CARPETAS_TOTAL carpetas, todas presentes" 1
  else
    revisar carpetas "Estructura de carpetas" "" 0
    info "faltan $CARPETAS_FALTAN de $CARPETAS_TOTAL carpetas"
  fi
else
  error "No encuentro $ARCHIVO_CARPETAS"
  revisar carpetas "Estructura de carpetas" "" 0
fi

# -- duplicados de Claude Code (npm + nativo a la vez)
DUPLICADOS=()
# Se ignoran los enlaces temporales del sistema: no son instalaciones duplicadas.
rutas_de() { { type -a "$1" 2>/dev/null || true; } | awk '{print $NF}' \
  | grep '^/' | grep -v '^/private/tmp/' | grep -v '^/var/folders/' | grep -v '^/tmp/' | sort -u; }
for _cmd in claude rtk; do
  _rutas="$(rutas_de "$_cmd")"
  _n=$(printf '%s\n' "$_rutas" | grep -c . )
  if [ "${_n:-0}" -gt 1 ]; then
    DUPLICADOS+=("$_cmd en varias rutas: $(printf '%s' "$_rutas" | tr '\n' ' ')")
  fi
done

if [ ${#DUPLICADOS[@]} -gt 0 ]; then
  printf '\n'
  for d in ${DUPLICADOS[@]+"${DUPLICADOS[@]}"}; do aviso "DUPLICADO — $d"; done
  aviso "El instalador NO borra nada por su cuenta. Revisá estas rutas a mano."
fi

# -- permisos de administrador
printf '\n'
if [ "$TIENE_ADMIN" = "1" ]; then
  ok "El usuario tiene permisos de administrador (necesarios para Google Drive)"
else
  aviso "El usuario NO es administrador: Google Drive no se podrá instalar. El resto sí."
fi

if [ "$MODO_DIAGNOSTICO" = "1" ]; then
  printf '\n%sDiagnóstico terminado. No se modificó nada.%s\nLog: %s\n' "$NEG" "$R" "$LOG"
  exit 0
fi

# ============================================================ CONFIRMACIÓN ==
titulo "2. Plan"

quiere() { # ¿esta pieza entra en el perfil elegido?
  case "$PERFIL" in
    # Node.js NO va acá: los hooks del plugin caveman lo ejecutan en cada sesión.
    basico) case "$1" in rtk|gstack|bun) return 1 ;; esac ;;
  esac
  return 0
}

PENDIENTES=()
for p in git uv claude claude_app rtk superpowers caveman gstack markitdown gdrive carpetas bun node; do
  quiere "$p" || continue
  [ "$(estado_de "$p")" = "1" ] && continue
  [ "$p" = "gdrive" ] && [ "$TIENE_ADMIN" = "0" ] && continue
  PENDIENTES+=("$p")
done

if [ ${#PENDIENTES[@]} -eq 0 ]; then
  ok "No falta nada. El equipo ya está completo."
else
  info "Perfil: $PERFIL"
  printf '  Se va a instalar:\n'
  for p in ${PENDIENTES[@]+"${PENDIENTES[@]}"}; do printf '    · %s\n' "$p"; done
fi

if [ "$SIN_PREGUNTAR" = "0" ] && [ "$DRY_RUN" = "0" ] && [ ${#PENDIENTES[@]} -gt 0 ]; then
  printf '\n  ¿Seguimos? [Enter para continuar, Ctrl+C para salir] '
  read -r _
fi

necesita() { for p in ${PENDIENTES[@]+"${PENDIENTES[@]}"}; do [ "$p" = "$1" ] && return 0; done; return 1; }

# ======================================================== DEPENDENCIAS BASE ==
titulo "3. Dependencias base"

if necesita git; then
  paso "git — pidiendo las Herramientas de Línea de Comandos de Apple"
  if [ "$DRY_RUN" = "0" ]; then
    xcode-select --install >>"$LOG" 2>&1
    aviso "Se abrió la ventana de Apple. Instalá las herramientas y volvé a ejecutar este instalador."
    anotar aviso "git" "requiere Command Line Tools de Apple (ventana abierta)"
  fi
else
  ok "git ya está"
  anotar ok "git" "$(detalle_de git)"
fi

if necesita uv; then
  paso "uv (gestor de Python que necesita markitdown)"
  if ejecutar "instalar uv" bash -c 'curl -LsSf https://astral.sh/uv/install.sh | sh'; then
    ok "uv instalado"; anotar ok "uv" "instalado ahora"
  else
    error "No pude instalar uv"; anotar error "uv" "falló la instalación"
  fi
else
  ok "uv ya está"; anotar ok "uv" "$(detalle_de uv)"
fi

# ripgrep: rtk lo usa para sus filtros. En Windows se instala con winget; acá
# solo hay Homebrew, así que si no está se avisa y se sigue.
if quiere rtk; then
  if hay rg; then
    ok "ripgrep ya está"; anotar ok "ripgrep" "presente"
  elif hay brew; then
    paso "ripgrep (lo necesita rtk)"
    if ejecutar "instalar ripgrep" brew install ripgrep; then
      ok "ripgrep instalado"; anotar ok "ripgrep" "instalado ahora"
    else
      aviso "No pude instalar ripgrep: algunos filtros de rtk no van a funcionar"
      anotar aviso "ripgrep" "falló brew install ripgrep"
    fi
  else
    aviso "Falta ripgrep y no hay Homebrew para instalarlo"
    info "Algunos filtros de rtk no van a funcionar. Se instala con: brew install ripgrep"
    anotar aviso "ripgrep" "ausente, sin Homebrew"
  fi
fi

if quiere bun; then
  if necesita bun; then
    paso "bun (lo necesita gstack)"
    if ejecutar "instalar bun" bash -c 'curl -fsSL https://bun.sh/install | bash'; then
      ok "bun instalado"; anotar ok "bun" "instalado ahora"
    else
      error "No pude instalar bun"; anotar error "bun" "falló la instalación"
    fi
  else
    ok "bun ya está"; anotar ok "bun" "$(detalle_de bun)"
  fi
fi

# Node.js portátil: la última LTS oficial en ~/.local/node, con enlaces en
# ~/.local/bin. No pide contraseña ni necesita Homebrew. Se verifica contra
# SHASUMS256.txt de nodejs.org.
instalar_node_portable() {
  local arq ver nombre tmp esperado real
  case "$ARQ" in arm64) arq=arm64 ;; *) arq=x64 ;; esac
  ver="$(curl -fsSL --connect-timeout 20 https://nodejs.org/dist/index.json 2>>"$LOG" \
         | grep -m1 '"lts":"' | sed 's/.*"version":"\(v[0-9.]*\)".*/\1/')"
  case "$ver" in v[0-9]*.[0-9]*.[0-9]*) ;; *) registrar "node portátil: versión rara '$ver'"; return 1 ;; esac
  nombre="node-$ver-darwin-$arq"
  tmp="$(mktemp -d)"
  if ! curl -fsSL --retry 2 --connect-timeout 20 -o "$tmp/$nombre.tar.gz" \
         "https://nodejs.org/dist/$ver/$nombre.tar.gz" 2>>"$LOG"; then
    rm -rf "$tmp"; return 1
  fi
  esperado="$(curl -fsSL "https://nodejs.org/dist/$ver/SHASUMS256.txt" 2>>"$LOG" \
              | awk -v f="$nombre.tar.gz" '$2==f {print $1}')"
  real="$(shasum -a 256 "$tmp/$nombre.tar.gz" | awk '{print $1}')"
  if [ -z "$esperado" ] || [ "$esperado" != "$real" ]; then
    registrar "node portátil: checksum no coincide (esperado $esperado, real $real)"
    rm -rf "$tmp"; return 1
  fi
  mkdir -p "$HOME/.local/bin"
  rm -rf "$HOME/.local/node"
  if ! tar -xzf "$tmp/$nombre.tar.gz" -C "$tmp" >>"$LOG" 2>&1 \
     || ! mv "$tmp/$nombre" "$HOME/.local/node"; then
    rm -rf "$tmp"; return 1
  fi
  rm -rf "$tmp"
  for b in node npm npx; do ln -sf "$HOME/.local/node/bin/$b" "$HOME/.local/bin/$b"; done
  hay node
}

if quiere node; then
  if necesita node; then
    # Lo necesitan los hooks del plugin caveman (en los dos perfiles) y gstack
    # para su prueba de Chromium. Con Homebrew se usa Homebrew; si no, la
    # versión portátil, que no pide contraseña.
    paso "Node.js"
    if [ "$DRY_RUN" = "1" ]; then
      info "[simulación] instalar Node.js"
    elif hay brew && ejecutar "instalar node" brew install node; then
      ok "Node.js instalado"; anotar ok "Node.js" "instalado ahora (Homebrew)"
    elif instalar_node_portable; then
      ok "Node.js instalado ($(node --version 2>/dev/null), portátil)"; anotar ok "Node.js" "instalado ahora (portátil, en tu perfil)"
    else
      aviso "No pude instalar Node.js: caveman y la prueba de Chromium de gstack no van a funcionar"
      info "Instalalo a mano desde https://nodejs.org/ y volvé a ejecutar este instalador."
      anotar aviso "Node.js" "instalar a mano"
    fi
  else
    ok "Node.js ya está"; anotar ok "Node.js" "$(detalle_de node)"
  fi
fi

export PATH="$HOME/.local/bin:$HOME/.bun/bin:$PATH"

# ============================================================= CLAUDE CODE ==
titulo "4. Claude Code"

if necesita claude; then
  paso "instalando Claude Code"
  if ejecutar "instalar claude" bash -c 'curl -fsSL https://claude.ai/install.sh | bash'; then
    ok "Claude Code instalado"; anotar ok "Claude Code" "instalado ahora"
  else
    error "Falló la instalación de Claude Code"; anotar error "Claude Code" "falló"
  fi
else
  ok "Claude Code ya está ($(detalle_de claude))"
  anotar ok "Claude Code" "$(detalle_de claude)"
fi

if necesita claude_app; then
  paso "descargando Claude para escritorio"
  DMG="/tmp/Claude-$(date +%s).dmg"
  # El enlace que publica claude.com/download (claude.ai/api/desktop/.../redirect)
  # está detrás de Cloudflare: desde un script devuelve 403 "Just a moment...",
  # también con cabeceras de navegador. Comprobado el 31/08/2026.
  # Se descarga entonces del bucket de Anthropic, que es de donde se sirve el
  # propio actualizador de la app. El enlace oficial queda de reserva por si
  # algún día deja de bloquear.
  URLS_APP="https://storage.googleapis.com/osprey-downloads-c02f6a0d-347c-492b-a752-3e0651722e97/nest/Claude.dmg
https://claude.ai/api/desktop/darwin/universal/dmg/latest/redirect"
  BAJADO=0
  if [ "$DRY_RUN" = "1" ]; then
    info "[simulación] descargar e instalar Claude para escritorio"
  else
    for u in $URLS_APP; do
      registrar "GET   $u"
      if curl -fsSL --retry 2 --connect-timeout 20 -o "$DMG" "$u" 2>>"$LOG"; then
        # Un .dmg real pesa cientos de MB. Si llegó una página de error, se descarta.
        TAM="$(stat -f%z "$DMG" 2>/dev/null || echo 0)"
        if [ "$TAM" -gt 52428800 ]; then BAJADO=1; break; fi
        registrar "descartado: solo $TAM bytes desde $u"
      fi
      rm -f "$DMG"
    done
  fi
  if [ "$BAJADO" = "1" ]; then
    if [ "$DRY_RUN" = "0" ]; then
      MP="/tmp/claude-mnt-$$"
      mkdir -p "$MP"
      if hdiutil attach "$DMG" -mountpoint "$MP" -nobrowse -quiet >>"$LOG" 2>&1; then
        APP="$(find "$MP" -maxdepth 1 -name '*.app' -print -quit)"
        if [ -n "$APP" ] && cp -R "$APP" /Applications/ >>"$LOG" 2>&1; then
          ok "Claude para escritorio instalada"; anotar ok "Claude escritorio" "instalada ahora"
        else
          error "No pude copiar la app a /Applications"; anotar error "Claude escritorio" "no se pudo copiar"
        fi
        hdiutil detach "$MP" -quiet >>"$LOG" 2>&1
      else
        error "No pude montar el .dmg"; anotar error "Claude escritorio" "no se pudo montar el dmg"
      fi
      rmdir "$MP" 2>/dev/null
      rm -f "$DMG"
    fi
  elif [ "$DRY_RUN" = "0" ]; then
    error "No pude descargar Claude para escritorio"
    info "Descargala a mano desde https://claude.com/download"
    anotar error "Claude escritorio" "falló la descarga"
  fi
else
  ok "Claude para escritorio ya está"; anotar ok "Claude escritorio" "presente"
fi

# ===================================================================== RTK ==
if quiere rtk; then
  titulo "5. rtk"
  if necesita rtk; then
    paso "instalando rtk"
    if ejecutar "instalar rtk" bash -c 'curl -fsSL https://raw.githubusercontent.com/rtk-ai/rtk/refs/heads/master/install.sh | sh'; then
      ok "rtk instalado"; anotar ok "rtk" "instalado ahora"
    else
      error "Falló la instalación de rtk"; anotar error "rtk" "falló"
    fi
  else
    ok "rtk ya está ($(detalle_de rtk))"; anotar ok "rtk" "$(detalle_de rtk)"
  fi
fi

# ============================================== PLUGINS, GSTACK, MARKITDOWN ==
titulo "6. Skills y plugins"

if necesita superpowers; then
  paso "instalando el plugin superpowers"
  ejecutar "añadir marketplace" claude plugin marketplace add anthropics/claude-plugins-official
  # OJO: sin --yes. Ese flag no existe en Claude Code 2.1.81 (commander aborta
  # con "unknown option '--yes'" y el plugin nunca se instala) y sí existe en
  # 2.1.251. Omitirlo funciona en las dos: --scope user es el valor por defecto,
  # pero se pasa explícito para no depender de él.
  ejecutar "instalar superpowers" claude plugin install superpowers@claude-plugins-official --scope user || true
  # Se re-verifica en vez de confiar en el código de salida: es el mismo criterio
  # que usa el de Windows.
  if [ "$DRY_RUN" = "1" ] || hay_superpowers; then
    ok "superpowers instalado"; anotar ok "superpowers" "instalado ahora"
  else
    aviso "No pude instalar superpowers automáticamente"
    info "Hacelo a mano: claude plugin install superpowers@claude-plugins-official"
    anotar aviso "superpowers" "instalar a mano"
  fi
else
  ok "superpowers ya está"; anotar ok "superpowers" "presente"
fi

# caveman: respuestas comprimidas, menos tokens. Sus hooks ejecutan 'node':
# sin Node.js no se instala, porque fallaría en cada mensaje.
if necesita caveman; then
  if [ "$DRY_RUN" = "0" ] && ! hay node; then
    aviso "Sin Node.js no instalo caveman (sus enganches lo necesitan)"
    anotar aviso "caveman" "falta Node.js"
  else
    paso "instalando el plugin caveman"
    ejecutar "añadir marketplace caveman" claude plugin marketplace add juliusbrussee/caveman || true
    ejecutar "instalar caveman" claude plugin install caveman@caveman --scope user || true
    if [ "$DRY_RUN" = "1" ] || hay_caveman; then
      ok "caveman instalado"; anotar ok "caveman" "instalado ahora"
    else
      aviso "No pude instalar caveman automáticamente"
      info "Hacelo a mano: claude plugin install caveman@caveman"
      anotar aviso "caveman" "instalar a mano"
    fi
  fi
else
  ok "caveman ya está"; anotar ok "caveman" "presente"
fi

if quiere gstack; then
  if necesita gstack; then
    paso "instalando gstack (descarga grande: puede tardar varios minutos)"
    if [ "$DRY_RUN" = "0" ]; then
      if ! hay git; then
        aviso "Sin git no puedo descargar gstack"
        anotar aviso "gstack" "falta git"
      else
      mkdir -p "$HOME/.claude/skills"
      # Un clone cortado a la mitad deja el destino no vacío, y a partir de ahí
      # TODOS los reintentos fallan. Se limpia antes de volver a intentar.
      if [ -d "$GSTACK_DIR" ] && [ ! -f "$MARCA_GSTACK" ]; then
        info "quedó una descarga de gstack a medias: la limpio y reintento"
        rm -rf "$GSTACK_DIR"
      fi
      if git clone --single-branch --depth 1 https://github.com/garrytan/gstack.git \
           "$GSTACK_DIR" >>"$LOG" 2>&1; then
        if (cd "$GSTACK_DIR" && ./setup -q --host claude >>"$LOG" 2>&1) && [ -f "$MARCA_GSTACK" ]; then
          ok "gstack instalado ($(cat "$GSTACK_DIR/VERSION" 2>/dev/null))"
          anotar ok "gstack" "instalado ahora"
        else
          aviso "gstack se descargó pero su instalador falló"
          info "Probá a mano: cd ~/.claude/skills/gstack && ./setup"
          anotar aviso "gstack" "descargado, setup falló"
        fi
      else
        error "No pude descargar gstack"; anotar error "gstack" "falló el clone"
      fi
      fi
    else
      info "[simulación] clonar gstack y ejecutar su setup"
    fi
  else
    ok "gstack ya está ($(detalle_de gstack))"; anotar ok "gstack" "$(detalle_de gstack)"
  fi
fi

# Playwright y su Chromium: gstack los usa para navegar. El setup de gstack no
# los baja, y en Windows se instalan aparte. Sin esto, /browse no funciona.
if quiere gstack && [ "$DRY_RUN" = "0" ] && [ -d "$GSTACK_DIR" ] && hay bun; then
  if [ -d "$HOME/Library/Caches/ms-playwright" ]; then
    ok "Chromium de Playwright ya está"; anotar ok "Playwright" "presente"
  else
    paso "descargando Chromium para gstack (unos 150 MB)"
    if (cd "$GSTACK_DIR" && bunx playwright install chromium >>"$LOG" 2>&1); then
      ok "Chromium instalado"; anotar ok "Playwright" "instalado ahora"
    else
      aviso "No pude instalar Chromium: la navegación de gstack no va a funcionar"
      info "Probá a mano: cd ~/.claude/skills/gstack && bunx playwright install chromium"
      anotar aviso "Playwright" "falló la descarga"
    fi
  fi
fi

if necesita markitdown; then
  paso "instalando markitdown"
  if ejecutar "instalar markitdown" uv tool install "markitdown[all]"; then
    ok "markitdown instalado"; anotar ok "markitdown" "instalado ahora"
  else
    error "Falló la instalación de markitdown"; anotar error "markitdown" "falló"
  fi
else
  ok "markitdown ya está ($(detalle_de markitdown))"; anotar ok "markitdown" "$(detalle_de markitdown)"
fi

# ========================================================== CONFIGURACIÓN ===
titulo "7. Configuración de Claude"

PLANTILLA="$DIR_BASE/config/settings-base.json"
if [ "$DRY_RUN" = "1" ]; then
  info "[simulación] fusionar $PLANTILLA con $AJUSTES"
elif [ ! -f "$PLANTILLA" ]; then
  error "No encuentro $PLANTILLA"; anotar error "configuración" "falta la plantilla"
elif ! asegurar_python; then
  error "Sin python3 no puedo aplicar la configuración de Claude"
  info "Sin esto, Claude Code te va a pedir permiso para cada acción y el plugin"
  info "superpowers no queda activado. Instalá las Herramientas de Línea de"
  info "Comandos de Apple (xcode-select --install) y volvé a ejecutar el instalador."
  anotar error "configuración" "falta python3: la configuración NO se aplicó"
else
  mkdir -p "$HOME/.claude"
  [ -f "$AJUSTES" ] && cp "$AJUSTES" "$AJUSTES.respaldo-$(date +%Y%m%d-%H%M%S)"
  TIENE_RTK=0; command -v rtk >/dev/null 2>&1 && TIENE_RTK=1
  TIENE_NODE=0; command -v node >/dev/null 2>&1 && TIENE_NODE=1
  if $PYTHON - "$AJUSTES" "$PLANTILLA" "$TIENE_RTK" "$TIENE_NODE" <<'PYFIN' >>"$LOG" 2>&1
import json, os, sys
destino, plantilla = sys.argv[1], sys.argv[2]
tiene_rtk, tiene_node = sys.argv[3] == "1", sys.argv[4] == "1"

base = {}
if os.path.exists(destino):
    try:
        with open(destino, encoding="utf-8") as f:
            base = json.load(f)
    except Exception:
        base = {}

with open(plantilla, encoding="utf-8") as f:
    nueva = json.load(f)

# Sin rtk instalado, no dejamos un hook que apunte a un comando inexistente.
if not tiene_rtk:
    nueva.get("hooks", {}).pop("PreToolUse", None)
    if not nueva.get("hooks"):
        nueva.pop("hooks", None)

# Sin Node.js no se activa caveman: sus hooks ejecutan 'node' y fallarían siempre.
if not tiene_node:
    nueva.get("enabledPlugins", {}).pop("caveman@caveman", None)

def fusionar(a, b):
    """b sobre a, sin borrar lo que ya hubiera."""
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(a.get(k), dict):
            fusionar(a[k], v)
        elif isinstance(v, list) and isinstance(a.get(k), list):
            for item in v:
                if item not in a[k]:
                    a[k].append(item)
        else:
            a[k] = v
    return a

with open(destino, "w", encoding="utf-8") as f:
    json.dump(fusionar(base, nueva), f, indent=2, ensure_ascii=False)
    f.write("\n")
print("configuración fusionada")
PYFIN
  then
    ok "settings.json actualizado (se guardó copia de seguridad del anterior)"
    anotar ok "configuración" "fusionada sin pisar lo existente"
  else
    error "No pude escribir la configuración"; anotar error "configuración" "falló la fusión"
  fi
fi

# --- Una política administrada gana sobre lo que acabamos de escribir.
for POLITICA in "/Library/Application Support/ClaudeCode/managed-settings.json" \
                "/etc/claude-code/managed-settings.json"; do
  if [ -f "$POLITICA" ]; then
    aviso "Hay una política administrada en $POLITICA"
    info "Tiene más precedencia que la configuración de usuario: el modo de permisos que escribe el instalador puede quedar ignorado en silencio."
    anotar aviso "configuración" "existe una política administrada: $POLITICA"
  fi
done

# --- Pre-aceptar el diálogo de confianza por carpeta.
# El modo bypassPermissions NO salta el "¿confiás en los archivos de esta
# carpeta?": aparece igual la primera vez en cada carpeta nueva. Se pre-acepta
# para Documentos y para cada raíz de carpetas.txt, igual que en Windows.
# OJO: ~/.claude.json guarda además la sesión y los MCP. Se fusiona con respaldo,
# nunca se sobrescribe, y si no es JSON válido no se toca.
CLAUDE_JSON="$HOME/.claude.json"
if [ "$DRY_RUN" = "1" ]; then
  info "[simulación] pre-aceptar el diálogo de confianza en ~/.claude.json"
elif ! asegurar_python; then
  error "Sin python3 no puedo pre-aceptar el diálogo de confianza"
  info "Claude te va a preguntar si confiás en cada carpeta la primera vez."
  anotar error "confianza" "falta python3: no se pre-aceptó"
else
  RAICES_TMP="$(mktemp)"
  printf '%s\n' "$HOME/Documents" > "$RAICES_TMP"
  if [ -f "$ARCHIVO_CARPETAS" ]; then
    while IFS= read -r linea || [ -n "$linea" ]; do
      linea="$(printf '%s' "$linea" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
      case "$linea" in ''|'#'*) continue ;; esac
      ruta="${linea%%|*}"
      ruta="$(printf '%s' "$ruta" | sed -e 's/[[:space:]]*$//')"
      [ -z "$ruta" ] && continue
      printf '%s\n' "$HOME/Documents/${ruta%%/*}" >> "$RAICES_TMP"
    done < "$ARCHIVO_CARPETAS"
  fi
  if $PYTHON - "$CLAUDE_JSON" "$RAICES_TMP" <<'PYCONF' >>"$LOG" 2>&1
import json, os, shutil, sys, time

destino, archivo_raices = sys.argv[1], sys.argv[2]

raices = []
with open(archivo_raices, encoding="utf-8") as f:
    for linea in f:
        r = linea.rstrip("\n")
        if r and r not in raices:
            raices.append(r)

cfg = {}
if os.path.exists(destino):
    try:
        with open(destino, encoding="utf-8") as f:
            cfg = json.load(f)
    except Exception:
        print("~/.claude.json no es JSON válido: no se toca")
        sys.exit(2)
    shutil.copy2(destino, destino + ".respaldo-" + time.strftime("%Y%m%d-%H%M%S"))

proyectos = cfg.setdefault("projects", {})
cambios = 0
for r in raices:
    entrada = proyectos.setdefault(r, {})
    if entrada.get("hasTrustDialogAccepted") is not True:
        entrada["hasTrustDialogAccepted"] = True
        cambios += 1

if cambios:
    tmp = destino + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, destino)

print("carpetas de confianza añadidas: %d de %d" % (cambios, len(raices)))
PYCONF
  then
    ok "Diálogo de confianza pre-aceptado para Documentos y las carpetas de trabajo"
    anotar ok "confianza" "pre-aceptada"
  else
    aviso "No pude pre-aceptar el diálogo de confianza (se pedirá la primera vez)"
    anotar aviso "confianza" "no se pudo pre-aceptar"
  fi
  rm -f "$RAICES_TMP"
fi

# =============================================================== CARPETAS ===
titulo "8. Estructura de carpetas"

if [ ! -f "$ARCHIVO_CARPETAS" ]; then
  error "No encuentro $ARCHIVO_CARPETAS"
  anotar error "carpetas" "falta config/carpetas.txt"
else
  CREADAS=0; YA=0
  while IFS= read -r linea; do
    linea="${linea%%$'\r'}"
    case "$linea" in ''|'#'*) continue ;; esac
    ruta="${linea%%|*}"; ruta="$(echo "$ruta" | sed 's/[[:space:]]*$//')"
    desc=""
    case "$linea" in *'|'*) desc="$(echo "${linea#*|}" | sed 's/^[[:space:]]*//')" ;; esac
    completa="$HOME/Documents/$ruta"
    if [ -d "$completa" ]; then
      YA=$((YA+1))
      continue
    fi
    if [ "$DRY_RUN" = "1" ]; then
      info "[simulación] crear $completa"
      CREADAS=$((CREADAS+1))
      continue
    fi
    if mkdir -p "$completa" 2>>"$LOG"; then
      CREADAS=$((CREADAS+1))
      if [ ! -f "$completa/README.md" ]; then
        {
          printf '# %s\n\n' "$(basename "$ruta")"
          [ -n "$desc" ] && printf '%s\n\n' "$desc"
          printf -- '---\n\nCarpeta creada por el instalador de entorno Claude.\n'
          printf 'Fecha: %s\n' "$(date '+%d/%m/%Y')"
        } > "$completa/README.md"
      fi
    else
      error "No pude crear $completa"
    fi
  done < "$ARCHIVO_CARPETAS"
  ok "$CREADAS carpetas creadas · $YA ya existían"
  anotar ok "carpetas" "$CREADAS creadas, $YA ya existían"
fi

# =========================================================== GOOGLE DRIVE ===
titulo "9. Google Drive"

if [ "$TIENE_ADMIN" = "0" ]; then
  aviso "Sin permisos de administrador no se puede instalar Google Drive"
  info "Pedíselo al área de sistemas, o instalalo desde https://www.google.com/drive/download/"
  anotar aviso "Google Drive" "omitido: el usuario no es administrador"
elif ! necesita gdrive; then
  ok "Google Drive ya está instalado"
  anotar ok "Google Drive" "presente"
else
  paso "descargando Google Drive para escritorio"
  DMG_GD="/tmp/GoogleDrive-$(date +%s).dmg"
  if ejecutar "descargar Drive" curl -fsSL -o "$DMG_GD" "https://dl.google.com/drive-file-stream/GoogleDrive.dmg"; then
    if [ "$DRY_RUN" = "0" ]; then
      MPG="/tmp/gd-mnt-$$"; mkdir -p "$MPG"
      if hdiutil attach "$DMG_GD" -mountpoint "$MPG" -nobrowse -quiet >>"$LOG" 2>&1; then
        PKG="$(find "$MPG" -maxdepth 1 -name '*.pkg' -print -quit)"
        if [ -n "$PKG" ]; then
          aviso "macOS va a pedir tu contraseña de administrador"
          if sudo installer -pkg "$PKG" -target / >>"$LOG" 2>&1; then
            ok "Google Drive instalado"
            anotar ok "Google Drive" "instalado ahora"
          else
            error "Falló la instalación de Google Drive"
            anotar error "Google Drive" "el instalador de Apple devolvió error"
          fi
        else
          error "No encontré el .pkg dentro del dmg"
          anotar error "Google Drive" "dmg sin pkg"
        fi
        hdiutil detach "$MPG" -quiet >>"$LOG" 2>&1
      else
        error "No pude montar el dmg de Google Drive"
        anotar error "Google Drive" "no se pudo montar"
      fi
      rmdir "$MPG" 2>/dev/null; rm -f "$DMG_GD"
    fi
  else
    error "No pude descargar Google Drive"
    info "Descargalo a mano desde https://www.google.com/drive/download/"
    anotar error "Google Drive" "falló la descarga"
  fi
fi

# ================================================================= PATH =====
titulo "10. PATH"

# El shell de inicio de sesión del usuario, no el del script (que siempre es bash).
case "${SHELL:-/bin/zsh}" in
  */bash) PERFIL_SHELL="$HOME/.bash_profile" ;;
  *)      PERFIL_SHELL="$HOME/.zprofile" ;;
esac
LINEA_PATH='export PATH="$HOME/.local/bin:$HOME/.bun/bin:$PATH"'
if [ "$DRY_RUN" = "1" ]; then
  info "[simulación] asegurar el PATH en $PERFIL_SHELL"
elif [ -f "$PERFIL_SHELL" ] && grep -Fq '.local/bin' "$PERFIL_SHELL" 2>/dev/null; then
  ok "El PATH ya estaba configurado"
else
  {
    printf '\n# Añadido por el instalador de entorno Claude — %s\n' "$(date '+%d/%m/%Y')"
    printf '%s\n' "$LINEA_PATH"
  } >> "$PERFIL_SHELL"
  ok "PATH añadido a $(basename "$PERFIL_SHELL")"
fi

# ====================================================== VERIFICACIÓN FINAL ==
titulo "11. Verificación final"

verificar() { # verificar "Etiqueta" comando...
  local etiqueta="$1"; shift
  if "$@" >/dev/null 2>&1; then ok "$etiqueta responde"; anotar ok "$etiqueta" "verificado"; return 0
  else error "$etiqueta NO responde"; anotar error "$etiqueta" "no responde tras instalar"; return 1; fi
}

# OJO: no se lleva un contador aparte. error() ya cuenta TODO lo que falló,
# también durante la instalación. Antes solo se miraba esta sección, así que un
# run con uv, markitdown, gstack y Drive rotos terminaba diciendo "✓ terminada".
verificar "Claude Code" claude --version
quiere rtk && verificar "rtk" rtk --version
verificar "markitdown" markitdown --version
verificar "uv" uv --version
[ -d "/Applications/Claude.app" ] && ok "Claude para escritorio presente" || aviso "Claude para escritorio ausente"
quiere gstack && { [ -f "$MARCA_GSTACK" ] && ok "gstack presente" || aviso "gstack ausente o a medio instalar"; }
FALLOS=$ERRORES

# ================================================================ REPORTE ===
if [ "$DRY_RUN" = "0" ]; then
  {
    cat <<'HTMLCAB'
<meta charset="utf-8"><title>Instalación — entorno Claude</title>
<style>
body{font:15px/1.6 -apple-system,"Segoe UI",Roboto,sans-serif;background:#f4f5f7;color:#16181d;margin:0}
.w{max-width:820px;margin:0 auto;padding:30px 20px 60px}
h1{font-size:23px;margin:0 0 4px}.sub{color:#5b6270;font-size:13px;margin:0 0 24px}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #dfe2e8;border-radius:8px;overflow:hidden}
th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #eef0f4;font-size:14px}
th{background:#f7f8fa;font-size:12px;text-transform:uppercase;letter-spacing:.4px;color:#4a5160}
tr:last-child td{border-bottom:0}
.ok{color:#1d6f42;font-weight:700}.aviso{color:#b8860b;font-weight:700}.error{color:#c0392b;font-weight:700}
.caja{background:#fff;border:1px solid #dfe2e8;border-left:4px solid #16181d;border-radius:6px;padding:14px 16px;margin:20px 0;font-size:14px}
code{background:#eceef2;padding:1px 5px;border-radius:3px;font-size:12.5px}
</style><div class="w">
HTMLCAB
    printf '<h1>Instalación del entorno Claude</h1>\n'
    printf '<p class="sub">%s · macOS %s (%s) · usuario %s · perfil %s</p>\n' \
      "$(date '+%d/%m/%Y %H:%M')" "$VERSION_MACOS" "$ARQ" "$USUARIO" "$PERFIL"
    printf '<table><thead><tr><th>Estado</th><th>Pieza</th><th>Detalle</th></tr></thead><tbody>\n'
    for fila in ${RESULTADOS[@]+"${RESULTADOS[@]}"}; do
      est="${fila%%|*}"; resto="${fila#*|}"; pieza="${resto%%|*}"; det="${resto#*|}"
      case "$est" in
        ok) marca='<span class="ok">✓ correcto</span>' ;;
        aviso) marca='<span class="aviso">! atención</span>' ;;
        *) marca='<span class="error">✗ error</span>' ;;
      esac
      printf '<tr><td>%s</td><td>%s</td><td>%s</td></tr>\n' "$marca" "$pieza" "$det"
    done
    printf '</tbody></table>\n'
    if [ ${#DUPLICADOS[@]} -gt 0 ]; then
      printf '<div class="caja"><b>Instalaciones duplicadas detectadas</b><br>El instalador no borró nada. Revisar a mano:<ul>'
      for d in ${DUPLICADOS[@]+"${DUPLICADOS[@]}"}; do printf '<li><code>%s</code></li>' "$d"; done
      printf '</ul></div>\n'
    fi
    cat <<HTMLPIE
<div class="caja"><b>Qué falta hacer a mano</b>
<ol>
<li><b>Iniciar sesión en Claude Code</b>: abrí la Terminal, escribí <code>claude</code> y seguí el navegador. Hace falta una cuenta con suscripción activa.</li>
<li><b>Iniciar sesión en Google Drive</b>: abrí la aplicación y entrá con tu cuenta de Google.</li>
<li><b>Reiniciar la Terminal</b> para que el PATH nuevo tome efecto.</li>
</ol></div>
<p class="sub">Log completo: <code>$LOG</code><br>Instalador versión $VERSION_INSTALADOR (beta)</p>
</div>
HTMLPIE
  } > "$REPORTE"
fi

# ================================================================= CIERRE ===
printf '\n%s══════════════════════════════════════════%s\n' "$NEG" "$R"
if [ "$DRY_RUN" = "1" ]; then
  printf '%sSimulación terminada.%s No se modificó nada.\n' "$NEG" "$R"
elif [ "$FALLOS" -eq 0 ]; then
  printf '%s%s✓ Instalación terminada.%s\n' "$NEG" "$VER" "$R"
else
  printf '%s%s! Terminado con %s problema(s).%s Mirá el reporte.\n' "$NEG" "$AMA" "$FALLOS" "$R"
fi

cat <<CIERRE

${NEG}Falta hacer a mano:${R}
  1. Abrí la Terminal y escribí ${NEG}claude${R} para iniciar sesión.
  2. Abrí Google Drive e iniciá sesión con tu cuenta de Google.
  3. Cerrá y volvé a abrir la Terminal (para el PATH).

Log:     $LOG
CIERRE
[ "$DRY_RUN" = "0" ] && printf 'Reporte: %s\n' "$REPORTE"
printf '\n'

if [ "$DRY_RUN" = "0" ] && [ -f "$REPORTE" ]; then
  open "$REPORTE" 2>/dev/null
fi

# Salir con el número de fallos: así quien lo lance desde otro script se entera.
if [ "$DRY_RUN" = "1" ]; then exit 0; fi
[ "$FALLOS" -gt 125 ] && exit 125
exit "$FALLOS"
