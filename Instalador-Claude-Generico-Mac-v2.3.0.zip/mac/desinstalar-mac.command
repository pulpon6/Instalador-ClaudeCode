#!/bin/bash
# ============================================================================
#  Desinstalador del entorno Claude (macOS)
#
#
#  Quita lo que instaló instalar-mac.command. NO borra las carpetas de
#  Documentos ni Google Drive: eso contiene trabajo de la persona.
#
#  Uso:
#    ./desinstalar-mac.command            pregunta pieza por pieza
#    ./desinstalar-mac.command --todo     quita todo sin preguntar
# ============================================================================

set -uo pipefail

TODO=0
[ "${1:-}" = "--todo" ] && TODO=1

export PATH="$HOME/.local/bin:$HOME/.bun/bin:$PATH"

R=$'\033[0m'; NEG=$'\033[1m'; VER=$'\033[32m'; AMA=$'\033[33m'; GRI=$'\033[90m'
ok()    { printf '  %s✓%s %s\n' "$VER" "$R" "$1"; }
aviso() { printf '  %s!%s %s\n' "$AMA" "$R" "$1"; }
info()  { printf '  %s·%s %s\n' "$GRI" "$R" "$1"; }

DIR_LOG="$HOME/Library/Logs/instalador-claude"
mkdir -p "$DIR_LOG"
LOG="$DIR_LOG/desinstalacion-$(date +%Y%m%d-%H%M%S).log"

clear
cat <<BANNER
${NEG}Desinstalador del entorno Claude${R}

Esto quita las herramientas que instaló el instalador.

${NEG}NO se toca:${R}
  · tus carpetas y archivos de Documentos
  · Google Drive ni nada sincronizado
  · tu cuenta de Claude

BANNER

if [ "$TODO" = "0" ]; then
  printf '¿Seguimos? [Enter para continuar, Ctrl+C para salir] '
  read -r _
else
  # --todo no puede ser un atajo silencioso: pide escribir BORRAR, igual que el
  # desinstalador de Windows.
  printf '%s--todo quita TODAS las piezas sin preguntar una por una.%s\n\n' "$AMA" "$R"
  printf 'Escribí %sBORRAR%s (en mayúsculas) y pulsá Enter para confirmar: ' "$NEG" "$R"
  read -r _conf
  if [ "$_conf" != "BORRAR" ]; then
    printf '\nNo se hizo nada.\n\n'
    exit 0
  fi
fi

preguntar() {
  [ "$TODO" = "1" ] && return 0
  printf '  ¿Quitar %s? [s/N] ' "$1"
  read -r resp
  case "$resp" in [sSyY]*) return 0 ;; *) return 1 ;; esac
}

printf '\n%sQuitando…%s\n' "$NEG" "$R"

# -- gstack
if [ -d "$HOME/.claude/skills/gstack" ]; then
  if preguntar "gstack (~1 GB)"; then
    rm -rf "$HOME/.claude/skills/gstack" >>"$LOG" 2>&1 && ok "gstack eliminado" || aviso "no pude eliminar gstack"
  else info "gstack: se deja"; fi
else info "gstack no estaba"; fi

# -- rtk
if command -v rtk >/dev/null 2>&1; then
  if preguntar "rtk"; then
    # Se borra la ruta REAL, no una supuesta, y después se comprueba.
    RUTA_RTK="$(command -v rtk 2>/dev/null || true)"
    [ -n "$RUTA_RTK" ] && rm -f "$RUTA_RTK" >>"$LOG" 2>&1
    rm -f "$HOME/.local/bin/rtk" >>"$LOG" 2>&1
    rm -rf "$HOME/.rtk" >>"$LOG" 2>&1
    hash -r 2>/dev/null || true
    if command -v rtk >/dev/null 2>&1; then
      aviso "rtk sigue respondiendo desde $(command -v rtk): quitalo a mano"
    else
      ok "rtk eliminado"
    fi

    # IMPRESCINDIBLE: quitar el enganche de rtk de settings.json. Si queda
    # apuntando a un comando que ya no existe, Claude Code falla en TODOS los
    # comandos de Bash y el usuario no tiene forma de saber por qué.
    AJ="$HOME/.claude/settings.json"
    if [ -f "$AJ" ] && grep -q 'rtk hook' "$AJ" 2>/dev/null; then
      if command -v python3 >/dev/null 2>&1; then
        cp "$AJ" "$AJ.respaldo-$(date +%Y%m%d-%H%M%S)"
        if python3 - "$AJ" <<'PYHOOK' >>"$LOG" 2>&1
import json, sys

destino = sys.argv[1]
try:
    with open(destino, encoding="utf-8") as f:
        cfg = json.load(f)
except Exception:
    print("settings.json no es JSON valido: no se toca")
    sys.exit(2)

hooks = cfg.get("hooks")
if isinstance(hooks, dict) and "PreToolUse" in hooks:
    quedan = [g for g in hooks["PreToolUse"]
              if "rtk hook" not in json.dumps(g, ensure_ascii=False)]
    if len(quedan) != len(hooks["PreToolUse"]):
        if quedan:
            hooks["PreToolUse"] = quedan
        else:
            del hooks["PreToolUse"]
        if not hooks:
            del cfg["hooks"]
        with open(destino, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2, ensure_ascii=False)
            f.write("\n")
        print("enganche de rtk quitado")
PYHOOK
        then
          ok "enganche de rtk quitado de settings.json"
        else
          aviso "No pude quitar el enganche de rtk de settings.json"
          info "Quitá a mano el bloque PreToolUse con 'rtk hook claude', o Claude Code va a fallar en cada comando."
        fi
      else
        aviso "Sin python3 no puedo quitar el enganche de rtk de settings.json"
        info "Quitalo a mano o Claude Code va a fallar en todos los comandos de Bash."
      fi
    fi
  else info "rtk: se deja"; fi
else info "rtk no estaba"; fi

# -- markitdown
if command -v markitdown >/dev/null 2>&1; then
  if preguntar "markitdown"; then
    uv tool uninstall markitdown >>"$LOG" 2>&1 && ok "markitdown eliminado" || aviso "no pude eliminar markitdown"
  else info "markitdown: se deja"; fi
else info "markitdown no estaba"; fi

# -- plugin superpowers
# OJO: se mira installed_plugins.json, no settings.json. La plantilla del
# instalador escribe el nombre del plugin en settings.json, así que grepearlo
# ahí da un falso positivo permanente.
if [ -f "$HOME/.claude/plugins/installed_plugins.json" ] && grep -q 'superpowers@' "$HOME/.claude/plugins/installed_plugins.json" 2>/dev/null; then
  if preguntar "el plugin superpowers"; then
    claude plugin uninstall superpowers@claude-plugins-official >>"$LOG" 2>&1 && ok "superpowers eliminado" || aviso "quitalo con: claude plugin uninstall superpowers@claude-plugins-official"
  else info "superpowers: se deja"; fi
fi

# -- plugin caveman
if [ -f "$HOME/.claude/plugins/installed_plugins.json" ] && grep -q 'caveman@' "$HOME/.claude/plugins/installed_plugins.json" 2>/dev/null; then
  if preguntar "el plugin caveman"; then
    claude plugin uninstall caveman@caveman >>"$LOG" 2>&1 && ok "caveman eliminado" || aviso "quitalo con: claude plugin uninstall caveman@caveman"
  else info "caveman: se deja"; fi
fi

# -- Claude para escritorio
if [ -d "/Applications/Claude.app" ]; then
  if preguntar "la aplicación Claude para escritorio"; then
    rm -rf "/Applications/Claude.app" >>"$LOG" 2>&1 && ok "Claude.app eliminada" || aviso "no pude eliminar Claude.app (¿está abierta?)"
  else info "Claude.app: se deja"; fi
fi

# -- Claude Code
if command -v claude >/dev/null 2>&1; then
  if preguntar "Claude Code (terminal)"; then
    RUTA_CLAUDE="$(command -v claude 2>/dev/null || true)"
    [ -n "$RUTA_CLAUDE" ] && rm -f "$RUTA_CLAUDE" >>"$LOG" 2>&1
    rm -f "$HOME/.local/bin/claude" >>"$LOG" 2>&1
    hash -r 2>/dev/null || true
    if command -v claude >/dev/null 2>&1; then
      aviso "claude sigue respondiendo desde $(command -v claude): quitalo a mano"
    else
      ok "Claude Code eliminado del PATH"
    fi
    info "La configuración y el historial siguen en ~/.claude"
  else info "Claude Code: se deja"; fi
fi

# -- configuración
if [ -d "$HOME/.claude" ]; then
  if preguntar "la configuración de Claude (~/.claude: ajustes, plugins e historial)"; then
    RESP="$HOME/claude-respaldo-$(date +%Y%m%d-%H%M%S)"
    mv "$HOME/.claude" "$RESP" >>"$LOG" 2>&1 \
      && ok "configuración movida a $RESP (no se borró: se puede recuperar)" \
      || aviso "no pude mover ~/.claude"
  else info "configuración: se deja"; fi
fi

cat <<CIERRE

${NEG}Listo.${R}

${NEG}Lo que NO se tocó, y hay que quitar a mano si hace falta:${R}
  · Google Drive — Aplicaciones → arrastrar "Google Drive" a la Papelera
  · Las carpetas de ~/Documents — son tuyas, con tu trabajo dentro
  · uv, bun, git — otras herramientas pueden estar usándolos
  · La línea del PATH en ~/.zprofile — inofensiva, pero se puede borrar

Log: $LOG

CIERRE
