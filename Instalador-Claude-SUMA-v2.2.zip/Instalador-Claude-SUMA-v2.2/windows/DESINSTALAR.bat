@echo off
setlocal EnableExtensions
title Desinstalador de entorno Claude - SUMA Beneficios

rem ===========================================================================
rem  ASCII PURO Y CRLF. Nada de acentos aca: toda la prosa en espanol vive
rem  en desinstalar-windows.ps1, que esta en UTF-8 con BOM.
rem
rem  No hace falta ejecutar como administrador.
rem ===========================================================================

echo.
echo   Desinstalador de entorno Claude - SUMA Beneficios
echo   ================================================
echo.

if not exist "%~dp0desinstalar-windows.ps1" (
    echo   ERROR: no encuentro desinstalar-windows.ps1 junto a este archivo.
    echo   Descargate la carpeta completa desde Google Drive.
    echo.
    pause
    exit /b 1
)

rem -LiteralPath es obligatorio: la ruta del paquete puede llevar corchetes [ ],
rem que -Path interpreta como comodin y hace que no encuentre nada.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Unblock-File -LiteralPath '%~dp0desinstalar-windows.ps1' -ErrorAction SilentlyContinue" >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0desinstalar-windows.ps1" %*
set "CODIGO=%errorlevel%"

if not "%CODIGO%"=="0" (
    echo.
    echo   El desinstalador termino con errores. Revisa el log que se indico arriba.
    echo.
    pause
)

endlocal
exit /b %CODIGO%
