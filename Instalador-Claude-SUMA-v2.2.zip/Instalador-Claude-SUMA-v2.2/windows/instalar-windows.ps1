﻿#Requires -Version 5.0
# ============================================================================
#  Instalador de entorno Claude - SUMA Beneficios (Windows)
#  v2.2 - Ricardo Nieto / iA.Agency - 2026-09-06
#
#  No ejecutes este archivo directamente: usá INSTALAR.bat (doble clic).
#
#  Parámetros:
#    -Perfil basico|completo   qué se instala (si no, se pregunta en pantalla)
#    -Diagnostico              solo revisa, no instala nada
#    -DryRun                   muestra qué haría, sin hacerlo
#    -Si                       no pide confirmación (para despliegue desatendido)
#    -Origen <ruta>            carpeta original del paquete en Google Drive
#
#  REGLAS DE MANTENIMIENTO (leer antes de tocar nada):
#
#  1. NUNCA uses -Path con una ruta variable. La ruta del paquete contiene
#     corchetes ("[ ARG SUMA BENEFICIOS ]") y los cmdlets del proveedor
#     FileSystem los interpretan como comodín. Usá -LiteralPath o los
#     helpers ExisteRuta / LeerTexto / LeerLineas / EscribirTexto.
#
#  2. NUNCA le pongas a un parámetro de función el mismo nombre que a una
#     variable de ámbito script, ni cambiando mayúsculas: PowerShell no las
#     distingue y el parámetro tapa la variable. Así se rompió la v1
#     ($detalle tapaba $Detalle).
#
#  3. NUNCA hagas 2>&1 sobre un ejecutable nativo. Usá CorrerNativo, que
#     redirige a archivo. Con $ErrorActionPreference='Stop', el 2>&1 sobre
#     un nativo genera NativeCommandError y aborta el script.
#
#  4. El usuario solo puede ver líneas que empiecen por [OK], [!], [X], -> o
#     un punto. Cualquier otra cosa en pantalla es un bug.
#
#  5. NUNCA llames a una función definida más abajo en el archivo. PowerShell
#     ejecuta las definiciones en orden: hasta que su línea no se ejecuta, la
#     función no existe, y con $ErrorActionPreference='Stop' eso mata el
#     script. Así se rompía la v2.1: el aviso de winget llamaba a Anotar, que
#     se definía 140 líneas más abajo, y el instalador moría entero en todo
#     equipo que no tuviera winget.
# ============================================================================

[CmdletBinding()]
param(
    [ValidateSet('completo','basico','')][string]$Perfil = '',
    [switch]$Diagnostico,
    [switch]$DryRun,
    [switch]$Si,
    [string]$Origen = ''
)

$ErrorActionPreference = 'Stop'          # nada pasa desapercibido
$ProgressPreference    = 'SilentlyContinue'
$VersionInstalador     = '2.2.0'

$script:Fallos = 0
$script:Avisos = 0

# --------------------------------------------------------------- ubicaciones
$DirScript = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$DirBase   = Split-Path -Parent $DirScript
$ArchivoCarpetas = Join-Path $DirBase 'config\carpetas.txt'
$Plantilla       = Join-Path $DirBase 'config\settings-base.json'
$Ajustes         = Join-Path $env:USERPROFILE '.claude\settings.json'

# Documentos puede estar redirigido por OneDrive o por Google Drive (Known
# Folder Move): hay que preguntárselo a Windows, no armarlo a mano.
$Documentos = [Environment]::GetFolderPath('MyDocuments')
if (-not $Documentos) { $Documentos = Join-Path $env:USERPROFILE 'Documents' }

# ------------------------------------------------------------------ registro
$DirLog = Join-Path $env:LOCALAPPDATA 'instalador-suma'
[void][System.IO.Directory]::CreateDirectory($DirLog)
$sello   = Get-Date -Format 'yyyyMMdd-HHmmss'
$Log     = Join-Path $DirLog "instalacion-$sello.log"
$Reporte = Join-Path $DirLog "reporte-$sello.html"

function Registrar($t) {
    try { "{0}  {1}" -f (Get-Date -Format 'HH:mm:ss'), $t | Add-Content -LiteralPath $Log -Encoding UTF8 } catch { }
}

# --------------------------------------------------------------- codificación
# Para que los acentos salgan bien en cmd.exe y en Windows Terminal.
# Este archivo está guardado en UTF-8 CON BOM: es el único encoding que
# PowerShell 5.1 y PowerShell 7 leen igual. Si lo guardás sin BOM, PS 5.1 lo
# interpreta como Windows-1252 y los acentos salen rotos.
$EncodingPrevio = $null
try {
    $EncodingPrevio           = [Console]::OutputEncoding
    [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
    $OutputEncoding           = [Console]::OutputEncoding
} catch { }

function RestaurarConsola {
    if ($EncodingPrevio) { try { [Console]::OutputEncoding = $EncodingPrevio } catch { } }
}

# ------------------------------------------------------------------- salidas
function Titulo($t) {
    Write-Host ''
    Write-Host $t -ForegroundColor White
    Write-Host ('-' * $t.Length) -ForegroundColor DarkGray
    Registrar "== $t"
}
function Ok($t)    { Write-Host "  [OK] $t" -ForegroundColor Green;  Registrar "OK    $t" }
function Aviso($t) { Write-Host "  [!]  $t" -ForegroundColor Yellow; Registrar "AVISO $t"; $script:Avisos++ }
function Fallo($t) { Write-Host "  [X]  $t" -ForegroundColor Red;    Registrar "ERROR $t"; $script:Fallos++ }
function Info($t)  { Write-Host "  .    $t" -ForegroundColor Gray;   Registrar "info  $t" }
function Paso($t)  { Write-Host "  ->   $t" -ForegroundColor Cyan;   Registrar "PASO  $t" }
function Nota($t)  { Write-Host "       $t" -ForegroundColor Gray;   Registrar "nota  $t" }

# ------------------------------------------------------------ rutas literales
function ExisteRuta($ruta) {
    if ([string]::IsNullOrWhiteSpace($ruta)) { return $false }
    return (Test-Path -LiteralPath $ruta)
}
function LeerTexto($ruta) {
    if (-not (ExisteRuta $ruta)) { return $null }
    # ReadAllText detecta el BOM y asume UTF-8 si no lo hay.
    try { return [System.IO.File]::ReadAllText($ruta) } catch { return $null }
}
function LeerLineas($ruta) {
    if (-not (ExisteRuta $ruta)) { return @() }
    try { return @([System.IO.File]::ReadAllLines($ruta)) } catch { return @() }
}
function CrearDir($ruta) {
    if ($ruta -and -not (ExisteRuta $ruta)) { [void][System.IO.Directory]::CreateDirectory($ruta) }
}
function EscribirTexto($ruta, $texto) {
    CrearDir (Split-Path -Parent $ruta)
    # UTF-8 SIN BOM: Set-Content -Encoding UTF8 en PS 5.1 mete BOM y rompe el JSON.
    [System.IO.File]::WriteAllText($ruta, $texto, (New-Object System.Text.UTF8Encoding($false)))
}

# ------------------------------------------------------------------- entorno
function Hay($cmd) {
    try { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) } catch { return $false }
}

function Refrescar-Path {
    # Conserva lo que ya tenía el proceso (un instalador puede haber añadido su
    # ruta solo en memoria) y deduplica sin distinguir mayúsculas.
    $partes = @(
        $env:Path,
        [Environment]::GetEnvironmentVariable('Path','Machine'),
        [Environment]::GetEnvironmentVariable('Path','User'),
        (Join-Path $env:USERPROFILE '.local\bin'),
        (Join-Path $env:USERPROFILE '.bun\bin'),
        (Join-Path $env:LOCALAPPDATA 'Programs\rtk'),
        # Aquí es donde vive winget. Normalmente ya está en el PATH del
        # usuario, pero si acabamos de registrar el paquete a mano puede que
        # todavía no: sin esta línea, RepararWinget haría el trabajo y luego
        # diría que fracasó.
        (Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps')
    ) | Where-Object { $_ } | ForEach-Object { $_ -split ';' } | Where-Object { $_.Trim() -ne '' }

    $vistas = New-Object System.Collections.Generic.HashSet[string]([StringComparer]::OrdinalIgnoreCase)
    $env:Path = (($partes | Where-Object { $vistas.Add($_.Trim().TrimEnd('\')) }) -join ';')
}
Refrescar-Path

function VersionDe($cmd, $bandera) {
    # OJO: no llamar '$args' a este parámetro; es una variable automática.
    if (-not (Hay $cmd)) { return '' }
    try {
        $salida = & $cmd $bandera 2>$null
        $primera = @($salida | Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] })[0]
        return ("$primera" -replace '\s+$','')
    } catch {
        Registrar "no pude leer la versión de $cmd"
        return ''
    }
}

# --------------------------------------------------- ejecución de comandos
function CitarArgumento([string]$a) {
    <#
      Cita un argumento segun las reglas de CommandLineToArgvW, que es como
      Windows vuelve a partir la linea de comandos en el proceso hijo.
    #>
    if ($null -eq $a -or $a -eq '') { return '""' }
    if ($a -notmatch '[\s"]') { return $a }
    $s = ''; $barras = 0
    foreach ($c in $a.ToCharArray()) {
        if ($c -eq '\') { $barras++; continue }
        if ($c -eq '"') { $s += ('\' * ($barras * 2 + 1)) + '"'; $barras = 0; continue }
        if ($barras) { $s += '\' * $barras; $barras = 0 }
        $s += $c
    }
    $s += '\' * ($barras * 2)
    return '"' + $s + '"'
}

function CorrerNativo {
    <#
      Ejecuta un .exe capturando salida y error EN ARCHIVO, nunca en la
      tubería de PowerShell. Con $ErrorActionPreference='Stop', hacer 2>&1
      sobre un nativo genera NativeCommandError y mata el script.
    #>
    param([string]$Exe, [string[]]$Argumentos = @(), [string]$Que = '',
          [int]$SegundosMax = 1800)

    Registrar "CMD $Exe $($Argumentos -join ' ')"
    $idTmp  = [guid]::NewGuid().ToString('N')
    $fSal   = Join-Path $env:TEMP "suma-out-$idTmp.txt"
    $fErr   = Join-Path $env:TEMP "suma-err-$idTmp.txt"
    $codigo = $null

    # Start-Process con redirecciones necesita un .exe de verdad. Varias de las
    # herramientas son envoltorios: npm es npm.cmd, y claude instalado por npm
    # deja claude.cmd y claude.ps1. Los envolvemos en su intérprete.
    $ruta = $Exe
    try {
        $g = Get-Command $Exe -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($g -and $g.Source) { $ruta = $g.Source }
    } catch { }
    if ($ruta -match '\.(cmd|bat)$') {
        $Argumentos = @('/c', $ruta) + $Argumentos
        $ruta = $env:ComSpec
    } elseif ($ruta -match '\.ps1$') {
        $Argumentos = @('-NoProfile','-ExecutionPolicy','Bypass','-File', $ruta) + $Argumentos
        $ruta = 'powershell.exe'
    }

    try {
        $sp = @{
            FilePath               = $ruta
            NoNewWindow            = $true
            Wait                   = $true
            PassThru               = $true
            RedirectStandardOutput = $fSal
            RedirectStandardError  = $fErr
            ErrorAction            = 'Stop'
        }
        # OJO: -ArgumentList con un array une los elementos con espacios y NO
        # los cita. Un solo argumento con espacios llega partido en varios.
        # Rompia gstack ('bash -lc "cd ... && ./setup"'), Playwright y la
        # migracion de npm (C:\Program Files\nodejs\). Se cita a mano y se
        # pasa una unica cadena ya armada.
        if ($Argumentos.Count -gt 0) {
            $sp['ArgumentList'] = (($Argumentos | ForEach-Object { CitarArgumento $_ }) -join ' ')
        }
        # stdin desde un archivo vacio: si la herramienta pregunta algo, recibe
        # fin de entrada en vez de dejar la ventana muda para siempre.
        $fEnt = Join-Path $env:TEMP "suma-in-$idTmp.txt"
        Set-Content -LiteralPath $fEnt -Value '' -NoNewline -ErrorAction SilentlyContinue
        if (ExisteRuta $fEnt) { $sp['RedirectStandardInput'] = $fEnt }
        $sp.Remove('Wait')
        $p = Start-Process @sp
        if ($p.WaitForExit($SegundosMax * 1000)) {
            $codigo = $p.ExitCode
        } else {
            Registrar "TIMEOUT tras $SegundosMax s: $Exe ($Que)"
            try { $p.Kill() } catch { }
            $codigo = -1
        }
    } catch {
        Registrar "ERROR al lanzar $Exe : $($_.Exception.Message)"
    } finally {
        foreach ($f in @($fSal, $fErr, (Join-Path $env:TEMP "suma-in-$idTmp.txt"))) {
            if (ExisteRuta $f) {
                $t = LeerTexto $f
                if ($t -and $t.Trim()) { try { Add-Content -LiteralPath $Log -Value $t -Encoding UTF8 } catch { } }
                Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue
            }
        }
    }

    Registrar "exit=$codigo ($Que)"
    return ($codigo -eq 0)
}

function EjecutarPS {
    <#
      Corre un script de instalación (los típicos 'irm ... | iex') en un
      PowerShell hijo. $ComandoEsperado es obligatorio en la práctica: el exit
      code no alcanza, el binario tiene que responder de verdad.
    #>
    param([string]$Descripcion, [string]$Script, [string]$ComandoEsperado = '')

    if ($DryRun) { Info "[simulación] $Descripcion"; return $true }

    # $ErrorActionPreference='Stop' DENTRO del hijo: así un error no terminante
    # del script descargado se convierte en exit code distinto de 0.
    $envoltorio = "`$ErrorActionPreference='Stop'; `$ProgressPreference='SilentlyContinue'; " +
                  "try { $Script } catch { Write-Output `$_.Exception.Message; exit 1 }; exit 0"

    $ok = CorrerNativo 'powershell.exe' @('-NoProfile','-ExecutionPolicy','Bypass','-Command', $envoltorio) $Descripcion
    if (-not $ok) { return $false }

    if ($ComandoEsperado) { Refrescar-Path; return (Hay $ComandoEsperado) }
    return $true
}

function Descargar($url, $destino, $que) {
    if ($DryRun) { Info "[simulación] descargar $que"; return $true }
    try {
        Registrar "GET $url"
        Invoke-WebRequest -Uri $url -OutFile $destino -UseBasicParsing -ErrorAction Stop
        if (-not (ExisteRuta $destino) -or ((Get-Item -LiteralPath $destino).Length -lt 1024)) {
            Registrar "ERROR descarga vacía o truncada: $destino"
            return $false
        }
        Unblock-File -LiteralPath $destino -ErrorAction SilentlyContinue
        return $true
    } catch {
        $codigo = ''
        try { if ($_.Exception.Response) { $codigo = " HTTP $([int]$_.Exception.Response.StatusCode)" } } catch { }
        Registrar "ERROR descarga${codigo}: $($_.Exception.Message)"
        return $false
    }
}

# ------------------------------------------------------ resultados (informe)
# OJO: esta lista y Anotar tienen que estar definidas ANTES del primer uso.
# Hasta la v2.1 vivían dentro del bloque de diagnóstico, más abajo, pero el
# aviso de winget que viene aquí debajo ya llamaba a Anotar. Resultado: en un
# equipo SIN winget el instalador moría con "El término 'Anotar' no se
# reconoce" antes de instalar nada — justo en los equipos que más lo
# necesitaban. PowerShell ejecuta las definiciones en orden: una función no
# existe hasta que su línea se ejecuta.
$script:Resultados = New-Object System.Collections.ArrayList
function Anotar {
    # Mismo cuidado que en Revisar con los nombres de los parámetros.
    param($EstadoPieza, $Pieza, $TextoDetalle)
    [void]$script:Resultados.Add([pscustomobject]@{
        Estado = $EstadoPieza; Pieza = $Pieza; Detalle = "$TextoDetalle"
    })
}

# ------------------------------------------------------------------- winget
function RepararWinget {
    <#
      Intenta dejar winget utilizable. Devuelve $true si lo consigue.

      Dos intentos, del más barato al más caro:
        1. Volver a registrar el paquete que YA está en el equipo. Es local,
           instantáneo y no pide permisos. Cubre el caso habitual: perfil de
           usuario recién creado, o imagen corporativa donde "Instalador de
           aplicaciones" está presente pero sin registrar para esta cuenta.
        2. Descargarlo de la URL oficial de Microsoft e instalarlo.

      Si los dos fallan devuelve $false y el instalador sigue adelante: lo que
      dependa de winget se avisa pieza por pieza, no se aborta.
    #>
    if ($DryRun) { Info '[simulación] habilitar winget'; return $true }

    # -- intento 1: volver a registrar el paquete que ya está
    try {
        $paquete = Get-AppxPackage -Name 'Microsoft.DesktopAppInstaller' -ErrorAction SilentlyContinue |
                   Sort-Object Version -Descending | Select-Object -First 1
        if ($paquete -and $paquete.InstallLocation) {
            $manifiesto = Join-Path $paquete.InstallLocation 'AppXManifest.xml'
            if (ExisteRuta $manifiesto) {
                Add-AppxPackage -DisableDevelopmentMode -Register $manifiesto -ErrorAction Stop
                Refrescar-Path
                if (Hay winget) { Registrar 'winget: recuperado por re-registro'; return $true }
            }
        }
    } catch {
        Registrar "winget: falló el re-registro ($($_.Exception.Message))"
    }

    # -- intento 2: descargarlo de Microsoft
    # aka.ms/getwinget es la dirección oficial del paquete de la Store.
    # El archivo se deja en TEMP: los nombres de cuenta de Windows no admiten
    # corchetes, así que esa ruta nunca los lleva y el -Path de Add-AppxPackage
    # (que no tiene -LiteralPath) es seguro aquí. Es la única excepción a la
    # regla 1 de la cabecera, y por eso queda escrita.
    $bundle = Join-Path $env:TEMP 'suma-winget.msixbundle'
    if (Descargar 'https://aka.ms/getwinget' $bundle 'Instalador de aplicaciones (winget)') {
        try {
            Add-AppxPackage -Path $bundle -ErrorAction Stop
            Refrescar-Path
        } catch {
            # Lo más común aquí es que falte una dependencia (VCLibs) en
            # equipos con Windows 10 viejo. No hay nada que el instalador
            # pueda hacer sin permisos: se registra y se sigue.
            Registrar "winget: falló la instalación del paquete ($($_.Exception.Message))"
        }
        Remove-Item -LiteralPath $bundle -Force -ErrorAction SilentlyContinue
    }
    return (Hay winget)
}

$HayWinget = Hay winget
if (-not $HayWinget) {
    if ($Diagnostico) {
        # En diagnóstico no se toca nada, ni siquiera para arreglar winget.
        Aviso 'No encuentro winget (en modo diagnóstico no se instala nada)'
        Anotar 'aviso' 'winget' 'ausente'
    } else {
        Paso 'No encuentro winget: intento habilitarlo'
        $HayWinget = RepararWinget
        if ($HayWinget) {
            Ok 'winget habilitado'
            Anotar 'ok' 'winget' 'habilitado por el instalador'
        } else {
            # Sin winget caen Git, Node, Python, ripgrep y Claude escritorio.
            # Se dice una vez y con la causa, en vez de cinco fallos sueltos
            # que parecen cinco problemas distintos.
            Aviso 'Sin winget no puedo instalar Git, Node.js, Python, ripgrep ni Claude para escritorio'
            Nota 'winget viene en "Instalador de aplicaciones" (App Installer). Instalalo desde la Microsoft Store y volvé a ejecutar esto.'
            Nota 'Si la Store está bloqueada en el equipo, pedíselo a IT de SUMA: es un requisito, no un capricho.'
            Anotar 'aviso' 'winget' 'ausente: varias piezas no se pueden instalar'
        }
    }
}

function InstalarConWinget($id, $etiqueta, $comando) {
    if (-not $HayWinget) { return $false }
    if ($DryRun) { Info "[simulación] winget install $id"; return $true }
    Paso "$etiqueta"
    # -e (exacto)            : sin esto un match parcial abre un menú.
    # --disable-interactivity: garantía dura de que no se cuelgue esperando
    #                          una respuesta en una ventana de doble clic.
    # --scope user           : evita pedir elevación.
    # OJO: no llamar '$args' a esta variable; es una variable automática.
    $parametros = @('install','--id',$id,'-e','--silent','--scope','user',
                    '--accept-package-agreements','--accept-source-agreements','--disable-interactivity')
    [void](CorrerNativo 'winget' $parametros "winget install $id")
    Refrescar-Path
    # El código de salida de winget no es de fiar: comprobamos el comando.
    if ($comando) { return (Hay $comando) }
    return $true
}

function Intentar {
    param([string]$Que, [scriptblock]$Accion, [string]$SiFalla = '')
    try { & $Accion; return $true }
    catch {
        Registrar "ERROR [$Que] $($_.Exception.GetType().Name): $($_.Exception.Message)"
        Registrar "  traza: $($_.ScriptStackTrace)"
        Fallo $Que
        if ($SiFalla) { Nota $SiFalla }
        return $false
    }
}

# ------------------------------------------------------- red de seguridad
trap {
    Registrar "EXCEPCIÓN NO CONTROLADA: $($_.Exception.Message)"
    Registrar "  en: $($_.InvocationInfo.ScriptName):$($_.InvocationInfo.ScriptLineNumber)"
    Registrar "  traza: $($_.ScriptStackTrace)"
    Write-Host ''
    Write-Host '  [X]  Algo salió mal y el instalador tuvo que parar.' -ForegroundColor Red
    Write-Host "       Mandale este archivo a Ricardo:" -ForegroundColor Red
    Write-Host "       $Log" -ForegroundColor Red
    Write-Host ''
    RestaurarConsola
    Read-Host '  Enter para cerrar'
    exit 1
}

# ================================================================ CONTEXTO ==
$EsAdmin = ([Security.Principal.WindowsPrincipal] `
            [Security.Principal.WindowsIdentity]::GetCurrent()
           ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$Arq    = $env:PROCESSOR_ARCHITECTURE
$VerWin = ''
try { $VerWin = (Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue).Caption } catch { }
if (-not $VerWin) { $VerWin = 'Windows' }

# --- Guarda crítica: elevado con una cuenta distinta a la del empleado -------
# Si alguien hace clic derecho > Ejecutar como administrador y el UAC pide las
# credenciales de OTRA cuenta, todo (Claude, .claude, plugins, PATH, carpetas)
# se instalaría en el perfil de ESA cuenta y el empleado se quedaría sin nada,
# con un reporte que dice "correcto". Preferimos abortar.
$duenoSesion = ''
try { $duenoSesion = (Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue).UserName } catch { }
$yoAhora = "$env:USERDOMAIN\$env:USERNAME"

if ($EsAdmin -and $duenoSesion -and ($duenoSesion -ne $yoAhora)) {
    Write-Host ''
    Write-Host '  ATENCIÓN - no puedo continuar así' -ForegroundColor Black -BackgroundColor Yellow
    Write-Host ''
    Write-Host "  Estás ejecutando el instalador con la cuenta '$yoAhora'," -ForegroundColor Yellow
    Write-Host "  pero quien está usando este equipo es '$duenoSesion'."     -ForegroundColor Yellow
    Write-Host ''
    Write-Host '  Si sigo, todo se instalaría en el escritorio del administrador'
    Write-Host "  y no en el de $duenoSesion. No serviría de nada."
    Write-Host ''
    Write-Host '  Qué hacer:'
    Write-Host '    1. Cerrá esta ventana.'
    Write-Host '    2. Hacé DOBLE CLIC en INSTALAR.bat (sin clic derecho).'
    Write-Host '    3. Si Windows pide permisos en algún momento, aceptalos.'
    Write-Host ''
    Registrar "ABORTADO: elevado como '$yoAhora' con sesión de '$duenoSesion'"
    RestaurarConsola
    Read-Host '  Enter para cerrar'
    exit 1
}

Write-Host ''
Write-Host 'Instalador del entorno Claude - SUMA Beneficios' -ForegroundColor White
Write-Host "versión $VersionInstalador · $VerWin · equipo $env:COMPUTERNAME · usuario $env:USERNAME" -ForegroundColor DarkGray
if ($DryRun) { Write-Host ''; Write-Host ' MODO SIMULACIÓN: no se va a modificar nada. ' -ForegroundColor Black -BackgroundColor Yellow }
Registrar "instalador $VersionInstalador | $VerWin | $Arq | equipo $env:COMPUTERNAME | usuario $env:USERNAME | admin=$EsAdmin | origen=$Origen"

# Quitar la marca de "descargado de internet" ahora que el paquete está en disco local.
try {
    Get-ChildItem -LiteralPath $DirBase -Recurse -File -ErrorAction SilentlyContinue |
        Unblock-File -ErrorAction SilentlyContinue
} catch { }

# Comprobación de integridad del paquete: mejor fallar acá que a mitad de camino.
$faltantes = @()
foreach ($f in @($ArchivoCarpetas, $Plantilla)) { if (-not (ExisteRuta $f)) { $faltantes += $f } }
if ($faltantes.Count -gt 0) {
    Write-Host ''
    Write-Host '  [X]  El paquete del instalador está incompleto.' -ForegroundColor Red
    foreach ($f in $faltantes) { Write-Host "       Falta: $f" -ForegroundColor Red }
    Write-Host ''
    Write-Host '       Descargá otra vez la carpeta completa desde Google Drive'
    Write-Host '       y volvé a intentarlo. Si sigue igual, avisale a Ricardo.'
    Write-Host ''
    Registrar "ABORTADO: paquete incompleto ($($faltantes -join ', '))"
    RestaurarConsola
    Read-Host '  Enter para cerrar'
    exit 1
}

# ============================================================== DIAGNÓSTICO ==
Titulo '1. Qué hay instalado ya'

$script:Estado  = @{}
$script:Detalle = @{}

function Revisar {
    # OJO: PowerShell NO distingue mayúsculas en nombres de variable. Un
    # parámetro llamado $detalle taparía el hashtable $Detalle de ámbito
    # script. Por eso los parámetros se llaman $Texto y $Presente, y las
    # escrituras van con el prefijo $script: explícito.
    param($Clave, $Etiqueta, $Texto, $Presente)
    # No todos los comandos responden a --version (markitdown, por ejemplo):
    # si está pero no sabemos la versión, no dejamos el renglón cortado.
    if ($Presente -and [string]::IsNullOrWhiteSpace("$Texto")) { $Texto = 'instalado' }
    $script:Estado[$Clave]  = [bool]$Presente
    $script:Detalle[$Clave] = "$Texto"
    if ($Presente) { Ok "$Etiqueta - $Texto" } else { Info "$Etiqueta - no instalado" }
}

# $script:Resultados y Anotar ya no viven aquí: están definidos arriba, junto a
# RepararWinget, porque el aviso de winget los usa antes de llegar a este punto.

$script:RutaPython    = $null   # python.exe de verdad, si lo encontramos
$script:PythonEnPath  = $false  # ¿responde escribiendo "python" a secas?

function BuscarPython {
    <#
      Localiza el python.exe DE VERDAD. Devuelve su ruta, o $null.

      Hay dos trampas, y la v2.1 solo esquivaba la primera:

        1. Windows trae un "stub" de python en WindowsApps que NO es Python:
           solo abre la Microsoft Store. Get-Command lo encuentra igual, así
           que una comprobación ingenua da un falso positivo.

        2. El orden del PATH no es de fiar. La v2.1 miraba SOLO la primera
           resolución (Select-Object -First 1) y, si esa era el stub, se
           rendía. Pero el stub puede ir por delante del Python real cuando la
           ventana que lanzó el instalador heredó un PATH viejo. Resultado: en
           un equipo CON Python 3.13 instalado, el instalador informaba
           "Python - no instalado" y lo reinstalaba al pedo.

      Por eso ahora se miran TODAS las resoluciones (-All) y, además, las
      carpetas donde el instalador oficial deja Python. Lo primero que sea un
      Python real gana.
    #>
    $candidatas = New-Object System.Collections.ArrayList

    foreach ($c in @('python','python3')) {
        try {
            foreach ($g in @(Get-Command $c -All -ErrorAction SilentlyContinue)) {
                if ($g.Source) { [void]$candidatas.Add([string]$g.Source) }
            }
        } catch { }
    }

    # Carpetas habituales, para el caso de PATH desactualizado.
    foreach ($raiz in @((Join-Path $env:LOCALAPPDATA 'Programs\Python'),
                        (Join-Path $env:ProgramFiles 'Python'))) {
        if (-not (ExisteRuta $raiz)) { continue }
        try {
            foreach ($d in @(Get-ChildItem -LiteralPath $raiz -Directory -ErrorAction SilentlyContinue |
                             Where-Object { $_.Name -match '^Python3' } |
                             Sort-Object Name -Descending)) {
                [void]$candidatas.Add((Join-Path $d.FullName 'python.exe'))
            }
        } catch { }
    }

    foreach ($ruta in $candidatas) {
        if ([string]::IsNullOrWhiteSpace($ruta))  { continue }
        if ($ruta -like '*\WindowsApps\*')        { continue }   # el stub de la Store
        if (-not (ExisteRuta $ruta))              { continue }
        if ((VersionDe $ruta '--version') -match 'Python\s+3') { return $ruta }
    }
    return $null
}

$script:RutaPython = BuscarPython
if ($script:RutaPython) {
    # ¿Le sirve al empleado escribir "python" en una terminal, o solo existe
    # en el disco? Lo segundo se arregla en el paso 12 (PATH).
    try {
        $primero = Get-Command 'python' -ErrorAction SilentlyContinue | Select-Object -First 1
        $script:PythonEnPath = ($primero -and $primero.Source -and
                                $primero.Source -notlike '*\WindowsApps\*')
    } catch { $script:PythonEnPath = $false }
}

function HayPython { return [bool]$script:RutaPython }

function VersionPython {
    if (-not $script:RutaPython) { return '' }
    $v = VersionDe $script:RutaPython '--version'
    if ($v -match 'Python\s+3') { return $v }
    return ''
}

$CachePlaywright = Join-Path $env:LOCALAPPDATA 'ms-playwright'
function HayPlaywright {
    # Tener el CLI no alcanza: sin navegadores descargados no sirve de nada.
    if (-not (Hay playwright)) { return $false }
    if (-not (ExisteRuta $CachePlaywright)) { return $false }
    try {
        return (@(Get-ChildItem -LiteralPath $CachePlaywright -Directory -ErrorAction SilentlyContinue |
                  Where-Object { $_.Name -match '^(chromium|firefox|webkit)' }).Count -gt 0)
    } catch { return $false }
}

Revisar 'git'        'Git'                    (VersionDe git '--version')        (Hay git)
Revisar 'claude'     'Claude Code'            (VersionDe claude '--version')     (Hay claude)
Revisar 'node'       'Node.js'                (VersionDe node '--version')       (Hay node)
Revisar 'python'     'Python'                 (VersionPython)                    (HayPython)
Revisar 'uv'         'uv'                     (VersionDe uv '--version')         (Hay uv)
Revisar 'rg'         'ripgrep'                (VersionDe rg '--version')         (Hay rg)
Revisar 'bun'        'bun'                    (VersionDe bun '--version')        (Hay bun)
Revisar 'playwright' 'Playwright'             (VersionDe playwright '--version') (HayPlaywright)
Revisar 'rtk'        'rtk'                    (VersionDe rtk '--version')        (Hay rtk)
Revisar 'markitdown' 'markitdown'             (VersionDe markitdown '--version') (Hay markitdown)

function AppEscritorio {
    $rutas = @(
        (Join-Path $env:LOCALAPPDATA 'AnthropicClaude\Claude.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Claude\Claude.exe')
    ) | Where-Object { ExisteRuta $_ }
    if ($rutas.Count -gt 0) { return $rutas[0] }
    # El paquete de winget es MSIX: no deja exe en LOCALAPPDATA.
    try { if (Get-AppxPackage -Name 'Claude' -ErrorAction SilentlyContinue) { return 'instalada (Microsoft Store)' } } catch { }
    return $null
}
Revisar 'claude_app' 'Claude para escritorio' 'instalada' ([bool](AppEscritorio))

# El estado real de un plugin vive en installed_plugins.json, NO en
# settings.json: settings.json solo dice si está habilitado. Grepear
# settings.json daría un falso positivo permanente, porque nuestra propia
# plantilla escribe ahí el nombre del plugin.
$ArchivoPlugins = Join-Path $env:USERPROFILE '.claude\plugins\installed_plugins.json'
function HaySuperpowers {
    $t = LeerTexto $ArchivoPlugins
    return ([bool]($t -and $t -match 'superpowers@'))
}
Revisar 'superpowers' 'Plugin superpowers' 'instalado' (HaySuperpowers)

# gstack se da por instalado solo si su setup TERMINÓ. El archivo VERSION
# viene en el repo y existe apenas termina el clone, así que por sí solo no
# distingue una instalación completa de un clone a medias.
$VerGstack   = Join-Path $env:USERPROFILE '.claude\skills\gstack\VERSION'
$MarcaGstack = Join-Path $env:USERPROFILE '.gstack\.last-setup-version'
$gsHay = (ExisteRuta $VerGstack) -and (ExisteRuta $MarcaGstack)
Revisar 'gstack' 'gstack' $(if ($gsHay) { "$(LeerTexto $VerGstack)".Trim() } else { '' }) $gsHay

$HayDrive = @(
    (Join-Path $env:ProgramFiles 'Google\Drive File Stream'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Drive File Stream')
) | Where-Object { ExisteRuta $_ }
Revisar 'gdrive' 'Google Drive' 'instalado' ([bool]$HayDrive)

# -- carpetas
$LineasCarpetas = @(LeerLineas $ArchivoCarpetas |
    Where-Object { $_.Trim() -ne '' -and -not $_.TrimStart().StartsWith('#') })
$faltanCarpetas = 0
foreach ($l in $LineasCarpetas) {
    $r = ($l -split '\|')[0].Trim()
    if (-not (ExisteRuta (Join-Path $Documentos $r))) { $faltanCarpetas++ }
}
Revisar 'carpetas' 'Carpetas de trabajo' "$($LineasCarpetas.Count) carpetas" `
        (($faltanCarpetas -eq 0) -and ($LineasCarpetas.Count -gt 0))
if ($faltanCarpetas -gt 0) { Info "faltan $faltanCarpetas de $($LineasCarpetas.Count) carpetas" }

# -- duplicados
function BuscarDuplicados {
    $lista = @()
    foreach ($c in @('claude','rtk','node')) {
        try {
            $rutas = @(Get-Command $c -All -ErrorAction SilentlyContinue |
                       Select-Object -ExpandProperty Source -Unique |
                       Where-Object { $_ })
            # claude.cmd + claude.ps1 + claude en la misma carpeta es UNA
            # instalación, no tres: agrupamos por carpeta.
            $carpetas = @($rutas | ForEach-Object { Split-Path -Parent $_ } | Select-Object -Unique)
            if ($carpetas.Count -gt 1) { $lista += "$c en varias carpetas: $($carpetas -join ' | ')" }
        } catch { }
    }
    return $lista
}
$Duplicados = BuscarDuplicados
if ($Duplicados.Count -gt 0) {
    Write-Host ''
    foreach ($d in $Duplicados) { Aviso "DUPLICADO - $d" }
    Nota 'El instalador no borra nada por su cuenta. Revisá esas rutas a mano.'
}

if ($Diagnostico) {
    Write-Host ''
    Write-Host 'Diagnóstico terminado. No se modificó nada.' -ForegroundColor White
    Write-Host "Log: $Log"
    RestaurarConsola
    Read-Host 'Enter para cerrar'
    exit 0
}

# ================================================================== PERFIL ==
if (-not $Perfil) {
    if ($Si) {
        $Perfil = 'basico'
    } else {
        Write-Host ''
        Write-Host '  ¿Qué querés instalar?' -ForegroundColor White
        Write-Host ''
        Write-Host '    1) Lo básico  - Claude para escritorio, Claude Code, Python,'
        Write-Host '                    markitdown (para leer PDF y Word) y tus carpetas'
        Write-Host '                    de trabajo. Descarga unos 250 MB.  RECOMENDADO.'
        Write-Host ''
        Write-Host '    2) Todo       - lo anterior más las herramientas técnicas'
        Write-Host '                    (Node.js, bun, ripgrep, Playwright, rtk, gstack).'
        Write-Host '                    Descarga cerca de 1,2 GB. Elegí esta opción solo'
        Write-Host '                    si Ricardo te lo pidió expresamente.'
        Write-Host ''
        $elec = Read-Host '  Escribí 1 o 2 y pulsá Enter [1]'
        $Perfil = if ($elec.Trim() -eq '2') { 'completo' } else { 'basico' }
    }
}
Registrar "perfil elegido: $Perfil"

# Piezas EN ORDEN DE INSTALACIÓN. El orden importa: cada pieza tiene que
# encontrar instalado lo que necesita.
#   git      -> lo necesitan gstack (clone) y su instalador (Git Bash)
#   claude   -> instalador nativo, NO necesita Node
#   node     -> trae npm incluido; gstack lo exige en Windows
#   uv/rg/bun-> dependencias de markitdown, rtk y gstack
#   rtk      -> necesita ripgrep
#   ajustes  -> antes que el plugin, para declarar el marketplace
#   plugins  -> necesitan que claude responda
#   gstack   -> necesita git + node + bun + Git Bash
#   python   -> herramienta general; markitdown usa el suyo propio vía uv
#   playwright-> necesita Node; gstack lo trae como dependencia pero sin navegadores
$TodasLasPiezas = @('git','claude','node','python','uv','rg','bun','playwright',
                    'rtk','markitdown','superpowers','gstack','claude_app','gdrive','carpetas')

# Lo que se salta el perfil básico: herramientas técnicas pesadas.
# playwright va acá porque necesita Node y descarga navegadores (~150 MB).
$SoloCompleto = @('node','rg','bun','playwright','rtk','gstack')

function Quiere($p) {
    if ($Perfil -eq 'basico' -and $SoloCompleto -contains $p) { return $false }
    return $true
}

$Pendientes = @()
foreach ($p in $TodasLasPiezas) {
    if (-not (Quiere $p)) { continue }
    if ($script:Estado[$p]) { continue }
    $Pendientes += $p
}
function Necesita($p) { return ($Pendientes -contains $p) }

$NombreLindo = @{
    git='Git'; claude='Claude Code'; node='Node.js'; python='Python 3'; uv='uv'
    rg='ripgrep'; bun='bun'; playwright='Playwright (navegador automatizado)'
    rtk='rtk'; markitdown='markitdown (leer PDF y Word)'; superpowers='plugin superpowers'
    gstack='gstack'; claude_app='Claude para escritorio'; gdrive='Google Drive'
    carpetas='tus carpetas de trabajo'
}

Titulo '2. Qué se va a instalar'
if ($Pendientes.Count -eq 0) {
    Ok 'No falta nada: este equipo ya está completo.'
} else {
    foreach ($p in $Pendientes) { Write-Host "    · $($NombreLindo[$p])" }
    Write-Host ''
    Write-Host '  Nada de esto borra ni modifica archivos tuyos.' -ForegroundColor Gray
    if (-not $Si -and -not $DryRun) {
        Write-Host ''
        $r = Read-Host '  Pulsá Enter para empezar, o escribí no y Enter para salir'
        if ($r.Trim() -match '^(n|no)$') {
            Write-Host ''
            Write-Host '  Listo, no se instaló nada.' -ForegroundColor White
            RestaurarConsola
            Read-Host '  Enter para cerrar'
            exit 0
        }
        Write-Host ''
        Write-Host '  Esto puede tardar entre 5 y 20 minutos según tu conexión.' -ForegroundColor Gray
        Write-Host '  Podés seguir trabajando, pero no cierres esta ventana.'    -ForegroundColor Gray
    }
}

# =================================================================== 3. GIT ==
Titulo '3. Git'

if (Necesita 'git') {
    if (InstalarConWinget 'Git.Git' 'instalando Git' 'git') {
        Ok 'Git instalado'; Anotar 'ok' 'Git' 'instalado ahora'
    } else {
        Fallo 'No pude instalar Git'
        Nota 'Instalalo a mano desde https://git-scm.com/download/win'
        Anotar 'error' 'Git' 'instalar a mano'
    }
} else { Ok "Git ya está ($($script:Detalle['git']))"; Anotar 'ok' 'Git' $script:Detalle['git'] }

# =========================================================== 4. CLAUDE CODE ==
Titulo '4. Claude Code'

if (Necesita 'claude') {
    Paso 'instalando Claude Code'
    # El instalador nativo es el método recomendado y NO necesita Node.js.
    if (EjecutarPS 'instalar claude' 'irm https://claude.ai/install.ps1 | iex' 'claude') {
        Ok 'Claude Code instalado'; Anotar 'ok' 'Claude Code' 'instalado ahora'
    } elseif (InstalarConWinget 'Anthropic.ClaudeCode' 'reintentando Claude Code con winget' 'claude') {
        Ok 'Claude Code instalado (winget)'; Anotar 'ok' 'Claude Code' 'instalado ahora (winget)'
    } else {
        Fallo 'No pude instalar Claude Code'
        Nota 'Es la pieza principal: avisale a Ricardo antes de seguir.'
        Anotar 'error' 'Claude Code' 'fallo la instalación'
    }
} else {
    Ok "Claude Code ya está ($($script:Detalle['claude']))"
    Anotar 'ok' 'Claude Code' $script:Detalle['claude']

    # Claude Code dejó de distribuirse por npm y pasó al instalador nativo.
    # Si lo encontramos en la carpeta global de npm hay que migrarlo: si no, el
    # empleado se queda en la versión vieja y ve el aviso "Claude Code has
    # switched from npm to native installer" cada vez que lo abre.
    $rutaClaude = ''
    try { $rutaClaude = (Get-Command claude -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source) } catch { }
    if ($rutaClaude -like '*\npm\*') {
        Paso 'migrando Claude Code de npm al instalador nativo'
        if ($DryRun) {
            Info '[simulación] claude install'
        } else {
            [void](CorrerNativo 'claude' @('install') 'claude install (migración desde npm)')
            Refrescar-Path
            if (ExisteRuta (Join-Path $env:USERPROFILE '.local\bin\claude.exe')) {
                Ok 'Claude Code migrado al instalador nativo'
                Nota 'Queda la copia vieja de npm. Para quitarla, en una terminal nueva:'
                Nota '  npm uninstall -g @anthropic-ai/claude-code'
                Anotar 'ok' 'Claude Code' 'migrado de npm a nativo'
            } else {
                Aviso 'No pude confirmar la migración de Claude Code a nativo'
                Nota  'Hacelo a mano: abrí una terminal nueva y escribí  claude install'
                Anotar 'aviso' 'Claude Code' 'migrar a nativo a mano'
            }
        }
    }
}

# ========================================================= 5. DEPENDENCIAS ==
Titulo '5. Herramientas de apoyo'

if ((Quiere 'node') -and (Necesita 'node')) {
    # Node.js trae npm incluido: no son dos pasos. gstack lo exige en Windows.
    if (InstalarConWinget 'OpenJS.NodeJS.LTS' 'instalando Node.js (incluye npm)' 'node') {
        Ok "Node.js instalado ($(VersionDe node '--version')) con npm $(VersionDe npm '--version')"
        Anotar 'ok' 'Node.js' 'instalado ahora (incluye npm)'
    } else {
        Aviso 'No pude instalar Node.js: gstack no va a funcionar'
        Anotar 'aviso' 'Node.js' 'instalar a mano'
    }
} elseif (Quiere 'node') { Ok "Node.js ya está ($($script:Detalle['node']))"; Anotar 'ok' 'Node.js' $script:Detalle['node'] }

if (Necesita 'python') {
    # OJO: no le pasamos 'python' como comando a verificar. 'Hay python' daría
    # verdadero por el stub de la Microsoft Store aunque Python no esté.
    # Verificamos con HayPython, que descarta WindowsApps y confirma la versión.
    [void](InstalarConWinget 'Python.Python.3.13' 'instalando Python 3' '')
    Refrescar-Path
    # HayPython lee un valor cacheado en el diagnóstico, de ANTES de instalar.
    # Sin volver a buscar, Python recién instalado seguiría dando "no está".
    $script:RutaPython = BuscarPython
    if ($DryRun -or (HayPython)) {
        Ok "Python instalado ($(VersionPython))"; Anotar 'ok' 'Python' 'instalado ahora'
    } else {
        Aviso 'No pude instalar Python'
        Nota 'Instalalo a mano desde https://www.python.org/downloads/windows/'
        Nota 'Marcá la casilla "Add python.exe to PATH" en la primera pantalla.'
        Anotar 'aviso' 'Python' 'instalar a mano'
    }
} else { Ok "Python ya está ($($script:Detalle['python']))"; Anotar 'ok' 'Python' $script:Detalle['python'] }

if (Necesita 'uv') {
    Paso 'instalando uv (lo necesita markitdown)'
    if (EjecutarPS 'instalar uv' 'irm https://astral.sh/uv/install.ps1 | iex' 'uv') {
        Ok 'uv instalado'; Anotar 'ok' 'uv' 'instalado ahora'
    } else { Fallo 'No pude instalar uv'; Anotar 'error' 'uv' 'fallo' }
} else { Ok "uv ya está ($($script:Detalle['uv']))"; Anotar 'ok' 'uv' $script:Detalle['uv'] }

if ((Quiere 'rg') -and (Necesita 'rg')) {
    if (InstalarConWinget 'BurntSushi.ripgrep.MSVC' 'instalando ripgrep (lo necesita rtk)' 'rg') {
        Ok 'ripgrep instalado'; Anotar 'ok' 'ripgrep' 'instalado ahora'
    } else {
        Aviso 'No pude instalar ripgrep: algunos filtros de rtk no van a funcionar'
        Anotar 'aviso' 'ripgrep' 'instalar a mano'
    }
} elseif (Quiere 'rg') { Ok "ripgrep ya está ($($script:Detalle['rg']))"; Anotar 'ok' 'ripgrep' $script:Detalle['rg'] }

if ((Quiere 'bun') -and (Necesita 'bun')) {
    Paso 'instalando bun (lo necesita gstack)'
    if (EjecutarPS 'instalar bun' 'irm https://bun.sh/install.ps1 | iex' 'bun') {
        Ok 'bun instalado'; Anotar 'ok' 'bun' 'instalado ahora'
    } else { Aviso 'No pude instalar bun: gstack no se va a poder construir'; Anotar 'aviso' 'bun' 'fallo' }
} elseif (Quiere 'bun') { Ok "bun ya está ($($script:Detalle['bun']))"; Anotar 'ok' 'bun' $script:Detalle['bun'] }

if ((Quiere 'playwright') -and (Necesita 'playwright')) {
    if (Hay npm) {
        Paso 'instalando Playwright y su navegador (unos 150 MB)'
        Nota 'Puede tardar unos minutos. No cierres la ventana.'
        if (-not $DryRun) {
            [void](CorrerNativo 'npm' @('install','-g','playwright') 'npm install -g playwright')
            Refrescar-Path
            if (Hay playwright) {
                # Solo chromium: bajar los tres navegadores son más de 1 GB y
                # chromium es el que usan gstack y la automatización de Claude.
                # Para tener todos: playwright install
                [void](CorrerNativo 'playwright' @('install','chromium') 'playwright install chromium')
            }
        }
        if ($DryRun -or (HayPlaywright)) {
            Ok 'Playwright instalado con el navegador Chromium'
            Anotar 'ok' 'Playwright' 'instalado ahora (chromium)'
        } else {
            Aviso 'No pude confirmar la instalación de Playwright'
            Nota 'Hacelo a mano: npm install -g playwright  y después  playwright install chromium'
            Anotar 'aviso' 'Playwright' 'instalar a mano'
        }
    } else {
        Aviso 'Sin Node.js no puedo instalar Playwright'
        Anotar 'aviso' 'Playwright' 'falta Node.js'
    }
} elseif (Quiere 'playwright') { Ok "Playwright ya está ($($script:Detalle['playwright']))"; Anotar 'ok' 'Playwright' $script:Detalle['playwright'] }

# ==================================================== 6. RTK Y MARKITDOWN ==
Titulo '6. rtk y markitdown'

if (Quiere 'rtk') {
    if (Necesita 'rtk') {
        Paso 'descargando rtk'
        $binDir = Join-Path $env:USERPROFILE '.local\bin'
        CrearDir $binDir
        $zip = Join-Path $env:TEMP 'rtk-windows.zip'
        # Solo hay build x86_64; en equipos ARM corre por emulación.
        $urlRtk = 'https://github.com/rtk-ai/rtk/releases/latest/download/rtk-x86_64-pc-windows-msvc.zip'
        if (Descargar $urlRtk $zip 'rtk') {
            if (-not $DryRun) {
                $okRtk = Intentar 'No pude descomprimir rtk' {
                    Expand-Archive -LiteralPath $zip -DestinationPath $binDir -Force -ErrorAction Stop
                    Remove-Item -LiteralPath $zip -Force -ErrorAction SilentlyContinue
                    Refrescar-Path
                } 'Bajalo a mano de https://github.com/rtk-ai/rtk/releases'
                if ($okRtk -and (Hay rtk)) {
                    [void](CorrerNativo 'rtk' @('init','-g') 'rtk init -g')
                    Ok "rtk instalado ($(VersionDe rtk '--version'))"; Anotar 'ok' 'rtk' 'instalado ahora'
                } elseif ($okRtk) {
                    Aviso 'rtk se copió pero todavía no aparece en el PATH'
                    Anotar 'aviso' 'rtk' 'reiniciar la terminal'
                } else { Anotar 'error' 'rtk' 'fallo al descomprimir' }
            }
        } else {
            Fallo 'No pude descargar rtk'
            Nota 'Bajalo a mano de https://github.com/rtk-ai/rtk/releases'
            Anotar 'error' 'rtk' 'fallo la descarga'
        }
    } else { Ok "rtk ya está ($($script:Detalle['rtk']))"; Anotar 'ok' 'rtk' $script:Detalle['rtk'] }
}

if (Necesita 'markitdown') {
    if (Hay uv) {
        Paso 'instalando markitdown'
        if (-not $DryRun) {
            [void](CorrerNativo 'uv' @('tool','install','markitdown[all]') 'uv tool install markitdown')
            Refrescar-Path
        }
        if ($DryRun -or (Hay markitdown)) { Ok 'markitdown instalado'; Anotar 'ok' 'markitdown' 'instalado ahora' }
        else { Aviso 'markitdown se instaló pero todavía no aparece en el PATH'; Anotar 'aviso' 'markitdown' 'reiniciar la terminal' }
    } else { Fallo 'Sin uv no puedo instalar markitdown'; Anotar 'error' 'markitdown' 'falta uv' }
} else { Ok "markitdown ya está ($($script:Detalle['markitdown']))"; Anotar 'ok' 'markitdown' $script:Detalle['markitdown'] }

# ========================================== 7. CONFIGURACIÓN DE CLAUDE ======
# IMPORTANTE: este paso va ANTES de instalar el plugin. La plantilla declara
# el marketplace en extraKnownMarketplaces, y tenerlo declarado de antemano
# hace que 'claude plugin marketplace add' sea idempotente.
Titulo '7. Configuración de Claude'

function ObjetoAHash($o) {
    if ($o -is [System.Management.Automation.PSCustomObject]) {
        # [ordered] preserva el orden de las claves: sin esto, el settings.json
        # del usuario se reescribe barajado y queda ilegible.
        $h = [ordered]@{}
        foreach ($p in $o.PSObject.Properties) { $h[$p.Name] = ObjetoAHash $p.Value }
        return $h
    }
    if ($o -is [System.Collections.IEnumerable] -and $o -isnot [string]) {
        # La coma inicial impide que PowerShell desenrolle un array de un elemento.
        return ,@($o | ForEach-Object { ObjetoAHash $_ })
    }
    return $o
}

function Fusionar($a, $b) {
    # OJO: [ordered]@{} es OrderedDictionary, no Hashtable. Hay que comparar
    # contra IDictionary y usar .Contains(), porque .ContainsKey() no existe
    # en OrderedDictionary.
    foreach ($k in @($b.Keys)) {
        if ($b[$k] -is [System.Collections.IDictionary] -and $a.Contains($k) -and $a[$k] -is [System.Collections.IDictionary]) {
            $a[$k] = Fusionar $a[$k] $b[$k]
        } elseif ($b[$k] -is [array] -and $a.Contains($k) -and $a[$k] -is [array]) {
            $lista = @($a[$k])
            foreach ($item in $b[$k]) {
                $ya = $false
                foreach ($e in $lista) {
                    if ((ConvertTo-Json $e -Depth 20 -Compress) -eq (ConvertTo-Json $item -Depth 20 -Compress)) { $ya = $true; break }
                }
                if (-not $ya) { $lista += $item }
            }
            $a[$k] = $lista
        } else { $a[$k] = $b[$k] }
    }
    return $a
}

if ($DryRun) {
    Info "[simulación] fusionar la plantilla con $Ajustes"
} else {
    [void](Intentar 'No pude escribir la configuración de Claude' {
        CrearDir (Split-Path -Parent $Ajustes)

        $base = [ordered]@{}
        if (ExisteRuta $Ajustes) {
            Copy-Item -LiteralPath $Ajustes -Destination "$Ajustes.respaldo-$sello" -Force -ErrorAction Stop
            $crudo = LeerTexto $Ajustes
            if ($crudo -and $crudo.Trim()) {
                # -ErrorAction Stop: sin esto, un JSON inválido solo emite un
                # error NO terminante, deja $base en $null y revienta más abajo.
                try { $base = ObjetoAHash ($crudo | ConvertFrom-Json -ErrorAction Stop) }
                catch {
                    Aviso 'Tu settings.json actual no era JSON válido: se parte de cero'
                    Nota  "Se guardó una copia en $Ajustes.respaldo-$sello"
                    $base = [ordered]@{}
                }
            }
        }
        if ($base -isnot [System.Collections.IDictionary]) { $base = [ordered]@{} }

        $nueva = ObjetoAHash ((LeerTexto $Plantilla) | ConvertFrom-Json -ErrorAction Stop)
        if ($nueva -isnot [System.Collections.IDictionary]) { throw 'settings-base.json no contiene un objeto JSON' }

        # Sin rtk instalado no dejamos un hook que apunte a un comando que no existe:
        # Claude Code fallaría en cada comando de Bash.
        if (-not (Hay rtk)) {
            if ($nueva.Contains('hooks') -and $nueva['hooks'] -is [System.Collections.IDictionary]) {
                [void]$nueva['hooks'].Remove('PreToolUse')
                if ($nueva['hooks'].Count -eq 0) { [void]$nueva.Remove('hooks') }
                Info 'sin rtk: no se instala el enganche de rtk'
            }
            # Y si el equipo YA traía un enganche de rtk sin tener rtk, hay que
            # quitarlo: Fusionar agrega pero nunca quita, así que sobreviviría
            # y Claude Code fallaría en cada comando de Bash.
            if ($base.Contains('hooks') -and $base['hooks'] -is [System.Collections.IDictionary] -and
                $base['hooks'].Contains('PreToolUse')) {
                $limpios = @(@($base['hooks']['PreToolUse']) | Where-Object {
                    (ConvertTo-Json $_ -Depth 20 -Compress) -notmatch 'rtk\s+hook'
                })
                if ($limpios.Count -ne @($base['hooks']['PreToolUse']).Count) {
                    if ($limpios.Count -eq 0) { [void]$base['hooks'].Remove('PreToolUse') }
                    else { $base['hooks']['PreToolUse'] = $limpios }
                    Aviso 'Había un enganche de rtk en tu configuración pero rtk no está: lo quité'
                    Nota 'Con ese enganche roto, Claude Code falla en todos los comandos de Bash.'
                }
            }
        }

        $final = Fusionar $base $nueva
        EscribirTexto $Ajustes ($final | ConvertTo-Json -Depth 20)
        Ok 'settings.json actualizado (se guardó copia del anterior)'
        Anotar 'ok' 'Configuración' 'fusionada sin pisar lo existente'

        # No dejamos que los respaldos se acumulen sin límite.
        Get-ChildItem -LiteralPath (Split-Path -Parent $Ajustes) -Filter 'settings.json.respaldo-*' -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending | Select-Object -Skip 5 |
            Remove-Item -Force -ErrorAction SilentlyContinue
    } 'Se puede repetir después; hay copia de seguridad de tu configuración.')

    # --- ¿hay una política administrada que nos pise? ------------------------
    # Las "managed settings" tienen MÁS precedencia que la configuración de
    # usuario que acabamos de escribir, y permissions.defaultMode se lee solo
    # de la fuente de mayor rango. Si SUMA tiene una política puesta, lo
    # nuestro se ignora en silencio: mejor avisarlo que dejar creer que quedó.
    $fuentesManaged = @()
    if (ExisteRuta 'C:\Program Files\ClaudeCode\managed-settings.json') { $fuentesManaged += 'C:\Program Files\ClaudeCode\managed-settings.json' }
    foreach ($clave in @('HKLM:\SOFTWARE\Policies\ClaudeCode','HKCU:\SOFTWARE\Policies\ClaudeCode')) {
        try {
            if (Get-ItemProperty -LiteralPath $clave -Name 'Settings' -ErrorAction SilentlyContinue) { $fuentesManaged += $clave }
        } catch { }
    }
    if ($fuentesManaged.Count -gt 0) {
        Aviso 'Hay una política de Claude Code administrada en este equipo'
        foreach ($f in $fuentesManaged) { Nota $f }
        Nota 'Esa política manda sobre lo que configura el instalador.'
        Anotar 'aviso' 'Configuración' "política administrada presente ($($fuentesManaged -join '; '))"
    }
}

# ================================================== 8. PLUGINS Y SKILLS =====
Titulo '8. Plugins y skills'

if (Necesita 'superpowers') {
    if (Hay claude) {
        Paso 'instalando el plugin superpowers'
        if (-not $DryRun) {
            [void](CorrerNativo 'claude' @('plugin','marketplace','add','anthropics/claude-plugins-official') 'marketplace add')
            # OJO: NO existe el flag --yes en 'claude plugin install'. Pasarlo
            # hace que el comando aborte con "unknown option" y el plugin nunca
            # se instale. Así fallaba la v1.
            [void](CorrerNativo 'claude' @('plugin','install','superpowers@claude-plugins-official','--scope','user') 'plugin install')
        }
        # Verificamos contra installed_plugins.json, NUNCA grepeando
        # settings.json: nuestra propia plantilla escribe ahí el nombre del
        # plugin y daría un falso positivo permanente.
        if ($DryRun -or (HaySuperpowers)) {
            Ok 'superpowers instalado'; Anotar 'ok' 'superpowers' 'instalado ahora'
        } else {
            Aviso 'No pude confirmar la instalación de superpowers'
            Nota 'Se puede hacer después: claude plugin install superpowers@claude-plugins-official'
            Anotar 'aviso' 'superpowers' 'instalar a mano'
        }
    } else { Aviso 'Sin Claude Code no puedo instalar plugins'; Anotar 'aviso' 'superpowers' 'falta Claude Code' }
} elseif (Quiere 'superpowers') { Ok 'superpowers ya está'; Anotar 'ok' 'superpowers' 'presente' }

if ((Quiere 'gstack') -and (Necesita 'gstack')) {
    $destGstack = Join-Path $env:USERPROFILE '.claude\skills\gstack'
    if ($DryRun) {
        Info '[simulación] clonar gstack y ejecutar su setup'
    } elseif (-not (Hay git)) {
        Aviso 'Sin Git no puedo descargar gstack'; Anotar 'aviso' 'gstack' 'falta Git'
    } else {
        Paso 'descargando gstack (unos 900 MB)'
        Nota 'Es lo que más tarda: entre 3 y 15 minutos. Es normal que parezca'
        Nota 'colgado. No cierres la ventana.'

        # git clone no acepta un destino existente y no vacío. Si un intento
        # anterior se cortó a la mitad, sin esto el instalador quedaría roto
        # para siempre: 'Necesita gstack' sería true y el clone fallaría en
        # cada ejecución.
        if (ExisteRuta $destGstack) {
            Info 'había una descarga de gstack incompleta: se borra y se reintenta'
            Remove-Item -LiteralPath $destGstack -Recurse -Force -ErrorAction SilentlyContinue
        }
        CrearDir (Split-Path -Parent $destGstack)

        [void](CorrerNativo 'git' @('clone','--single-branch','--depth','1',
                                    'https://github.com/garrytan/gstack.git', $destGstack) 'git clone gstack')

        if (ExisteRuta (Join-Path $destGstack 'setup')) {
            # El instalador de gstack es un script bash: se ejecuta con el bash
            # de Git para Windows.
            $bash = @(
                (Join-Path $env:ProgramFiles 'Git\bin\bash.exe'),
                (Join-Path ${env:ProgramFiles(x86)} 'Git\bin\bash.exe'),
                (Join-Path $env:LOCALAPPDATA 'Programs\Git\bin\bash.exe')
            ) | Where-Object { ExisteRuta $_ } | Select-Object -First 1

            if ($bash) {
                # Git Bash necesita ruta estilo Unix: C:\Users\x -> /c/Users/x
                $rutaUnix = $destGstack -replace '\\','/'
                if ($rutaUnix -match '^([A-Za-z]):(.*)$') { $rutaUnix = '/' + $Matches[1].ToLower() + $Matches[2] }
                $rutaUnix = $rutaUnix.Replace("'", "'\''")
                $okSetup = CorrerNativo $bash @('-lc', "cd '$rutaUnix' && ./setup -q --host claude") 'gstack setup'

                # OJO: NO verificar con el archivo VERSION. VERSION está versionado
                # en el repo, así que existe apenas termina el git clone, antes de
                # que el setup haga nada: daba 'instalado' siempre. Se verifica con
                # el código de salida y con lo que el setup deja de verdad.
                $vGstack = Join-Path $destGstack 'VERSION'
                if ($okSetup -and (ExisteRuta $MarcaGstack)) {
                    $ver = if (ExisteRuta $vGstack) { "$(LeerTexto $vGstack)".Trim() } else { 'sin versión' }
                    Ok "gstack instalado ($ver)"
                    Anotar 'ok' 'gstack' 'instalado ahora'
                } else {
                    Aviso 'gstack se descargó pero su instalador no terminó'
                    # OJO: dentro de una cadena de PowerShell las comillas se
                    # escapan con acento grave (`") o duplicándolas (""). La
                    # barra invertida (\") NO escapa nada: parte la cadena ahí
                    # mismo y lo que sigue queda como código suelto. Escrito con
                    # \" esta línea rompía el ARCHIVO ENTERO con "El token '&&'
                    # no es un separador de instrucciones válido": un error de
                    # sintaxis, así que el instalador no arrancaba en absoluto.
                    Nota "Ejecutalo a mano: bash -lc `"cd '$rutaUnix' && ./setup --host claude`""
                    Anotar 'aviso' 'gstack' 'setup incompleto'
                }
            } else {
                Aviso 'gstack se descargó, pero falta el bash de Git para instalarlo'
                Nota 'Instalá Git para Windows y ejecutá: bash ~/.claude/skills/gstack/setup'
                Anotar 'aviso' 'gstack' 'falta el bash de Git'
            }
        } else {
            Fallo 'No pude descargar gstack'
            Anotar 'error' 'gstack' 'fallo la descarga'
        }
    }
} elseif (Quiere 'gstack') { Ok "gstack ya está ($($script:Detalle['gstack']))"; Anotar 'ok' 'gstack' $script:Detalle['gstack'] }

# =========================================== 9. CLAUDE PARA ESCRITORIO ======
Titulo '9. Claude para escritorio'

if (Necesita 'claude_app') {
    if ($DryRun) {
        Info '[simulación] instalar Claude para escritorio'
    } else {
        # OJO: NO usar https://claude.ai/api/desktop/.../redirect. Ese endpoint
        # devuelve 403 con Cf-Mitigated: challenge (desafío de Cloudflare),
        # también con User-Agent de navegador. No se puede descargar desde un
        # script. Verificado el 2026-08-28. La vía es winget.
        if (InstalarConWinget 'Anthropic.Claude' 'instalando Claude para escritorio' '') {
            if (AppEscritorio) { Ok 'Claude para escritorio instalada'; Anotar 'ok' 'Claude escritorio' 'instalada ahora' }
            else { Aviso 'No pude confirmar la instalación de Claude para escritorio'; Anotar 'aviso' 'Claude escritorio' 'revisar' }
        } else {
            Aviso 'No pude instalar Claude para escritorio automáticamente'
            Nota 'Descargala a mano desde https://claude.com/download'
            Anotar 'aviso' 'Claude escritorio' 'instalar a mano'
        }
    }
} else { Ok 'Claude para escritorio ya está'; Anotar 'ok' 'Claude escritorio' 'presente' }

# ================================================= 10. CARPETAS DE TRABAJO ==
Titulo '10. Carpetas de trabajo'

$lineas = @(LeerLineas $ArchivoCarpetas |
    Where-Object { $_.Trim() -ne '' -and -not $_.TrimStart().StartsWith('#') })

if ($lineas.Count -eq 0) {
    Fallo 'El archivo de carpetas está vacío'
    Anotar 'error' 'Carpetas' 'config\carpetas.txt vacío'
} else {
    $creadas = 0; $yaEstaban = 0; $conError = 0
    foreach ($linea in $lineas) {
        $partes   = $linea -split '\|', 2
        $ruta     = $partes[0].Trim()
        $desc     = if ($partes.Count -gt 1) { $partes[1].Trim() } else { '' }
        $completa = Join-Path $Documentos $ruta
        if (ExisteRuta $completa) { $yaEstaban++; continue }
        if ($DryRun) { Info "[simulación] crear $completa"; $creadas++; continue }
        try {
            [void][System.IO.Directory]::CreateDirectory($completa)
            $creadas++
            $readme = Join-Path $completa 'README.md'
            if (-not (ExisteRuta $readme)) {
                $texto = "# $(Split-Path $ruta -Leaf)`r`n`r`n"
                if ($desc) { $texto += "$desc`r`n`r`n" }
                $texto += "---`r`n`r`nCarpeta creada por el instalador de entorno Claude (SUMA Beneficios).`r`n"
                $texto += "Fecha: $(Get-Date -Format 'dd/MM/yyyy')`r`n"
                EscribirTexto $readme $texto
            }
        } catch {
            $conError++
            Registrar "ERROR carpeta ${completa}: $($_.Exception.Message)"
        }
    }
    if ($conError -gt 0) {
        Aviso "$creadas creadas · $yaEstaban ya estaban · $conError NO se pudieron crear (mirá el log)"
        Nota "en $Documentos"
        Anotar 'aviso' 'Carpetas' "$creadas creadas, $yaEstaban ya estaban, $conError con error"
    } else {
        Ok "$creadas creadas · $yaEstaban ya estaban"
        Nota "en $Documentos"
        Anotar 'ok' 'Carpetas' "$creadas creadas, $yaEstaban ya estaban"
    }

    # --- confianza de carpetas ---------------------------------------------
    # El diálogo "¿confiás en los archivos de esta carpeta?" NO lo salta el
    # modo bypassPermissions: aparece igual la primera vez que se abre Claude
    # en una carpeta nueva. Lo pre-aceptamos para las carpetas de trabajo.
    #
    # OJO: ~/.claude.json guarda la sesión, los MCP y el estado por proyecto.
    # Hay que FUSIONAR, nunca sobrescribir, y dejando respaldo. Además, si
    # Claude Code está abierto puede pisarnos el archivo al cerrarse.
    if (-not $DryRun) {
        [void](Intentar 'No pude pre-aceptar la confianza de las carpetas' {
            $archivoClaudeJson = Join-Path $env:USERPROFILE '.claude.json'

            $raices = New-Object System.Collections.Generic.HashSet[string]
            [void]$raices.Add($Documentos)
            foreach ($linea in $lineas) {
                $primera = (($linea -split '\|')[0].Trim() -split '/')[0].Trim()
                if ($primera) { [void]$raices.Add((Join-Path $Documentos $primera)) }
            }

            $cfg = [ordered]@{}
            if (ExisteRuta $archivoClaudeJson) {
                Copy-Item -LiteralPath $archivoClaudeJson -Destination "$archivoClaudeJson.respaldo-$sello" -Force -ErrorAction SilentlyContinue
                $crudoCj = LeerTexto $archivoClaudeJson
                if ($crudoCj -and $crudoCj.Trim()) {
                    try { $cfg = ObjetoAHash ($crudoCj | ConvertFrom-Json -ErrorAction Stop) }
                    catch { throw 'el archivo .claude.json existente no es JSON válido; no lo toco' }
                }
            }
            if ($cfg -isnot [System.Collections.IDictionary]) { $cfg = [ordered]@{} }
            if (-not $cfg.Contains('projects') -or $cfg['projects'] -isnot [System.Collections.IDictionary]) {
                $cfg['projects'] = [ordered]@{}
            }

            $nuevas = 0
            foreach ($r in $raices) {
                if (-not $cfg['projects'].Contains($r)) { $cfg['projects'][$r] = [ordered]@{} }
                if ($cfg['projects'][$r] -isnot [System.Collections.IDictionary]) { $cfg['projects'][$r] = [ordered]@{} }
                if ($cfg['projects'][$r]['hasTrustDialogAccepted'] -ne $true) {
                    $cfg['projects'][$r]['hasTrustDialogAccepted'] = $true
                    $nuevas++
                }
            }

            if ($nuevas -gt 0) {
                EscribirTexto $archivoClaudeJson ($cfg | ConvertTo-Json -Depth 30)
                Ok "$nuevas carpetas marcadas como de confianza"
                Anotar 'ok' 'Confianza' "$nuevas carpetas pre-aceptadas"
            } else {
                Ok 'Las carpetas ya estaban marcadas como de confianza'
            }
        } 'La primera vez que abras Claude te va a preguntar si confiás en la carpeta: respondé que sí.')
    }
}

# ===================================================== 11. GOOGLE DRIVE =====
Titulo '11. Google Drive'

if (-not (Necesita 'gdrive')) {
    Ok 'Google Drive ya está instalado'; Anotar 'ok' 'Google Drive' 'presente'
} elseif ($DryRun) {
    Info '[simulación] instalar Google Drive (pide permisos de administrador)'
} else {
    # Google Drive es la ÚNICA pieza que exige administrador. Elevamos SOLO
    # esta acción: el resto del instalador corre como el empleado, así nada
    # termina en el perfil equivocado. Si el empleado cancela el UAC, lo único
    # que se pierde es Drive.
    Write-Host ''
    Write-Host '  Google Drive necesita permisos de administrador.' -ForegroundColor Yellow
    Write-Host '  Va a aparecer una ventana de Windows pidiendo permiso.'
    Write-Host '  Si te pide usuario y contraseña de administrador y no los tenés,'
    Write-Host '  pulsá "No": todo lo demás ya está instalado y no se pierde.'
    Write-Host ''

    # La descarga se hace SIN privilegios (no hace falta) y solo el instalador
    # se lanza elevado. No usamos 'winget --verb RunAs': winget es un alias de
    # ejecución de la Store y no siempre resuelve en un proceso elevado.
    $instalado = $false
    $exeGD = Join-Path $env:TEMP 'GoogleDriveSetup.exe'
    if (Descargar 'https://dl.google.com/drive-file-stream/GoogleDriveSetup.exe' $exeGD 'Google Drive') {
        try {
            $p = Start-Process -FilePath $exeGD -Verb RunAs -Wait -PassThru -ErrorAction Stop `
                 -ArgumentList '--silent','--skip_launch_new','--gsuite_shortcuts=false'
            Registrar "gdrive exit=$($p.ExitCode)"
            $instalado = ($p.ExitCode -eq 0)
        } catch {
            Registrar "gdrive: no se dieron los permisos ($($_.Exception.Message))"
        }
        Remove-Item -LiteralPath $exeGD -Force -ErrorAction SilentlyContinue
    } else {
        Registrar 'gdrive: falló la descarga'
    }
    if ($instalado) { Ok 'Google Drive instalado'; Anotar 'ok' 'Google Drive' 'instalado ahora' }
    else {
        Aviso 'Google Drive no se instaló'
        Nota 'Se puede instalar después desde https://www.google.com/drive/download/'
        Nota 'o pedírselo a IT de SUMA. El resto de la instalación está bien.'
        Anotar 'aviso' 'Google Drive' 'sin instalar'
    }
}

# ================================================================ 12. PATH ==
Titulo '12. PATH'

$binUsuario = Join-Path $env:USERPROFILE '.local\bin'
$binBun     = Join-Path $env:USERPROFILE '.bun\bin'
$claveEnv   = 'HKCU:\Environment'

# OJO: NO usar [Environment]::GetEnvironmentVariable(...,'User') /
# SetEnvironmentVariable(...,'User'):
#   - Get devuelve el valor YA EXPANDIDO, así que al reescribirlo se pierden
#     los %USERPROFILE% que el usuario tuviera en su PATH.
#   - Set escribe REG_SZ y degrada el REG_EXPAND_SZ original.
# Ambas cosas son irreversibles. Trabajamos sobre el valor CRUDO del registro.
[void](Intentar 'No pude actualizar el PATH' {
    $claveReg  = Get-Item -LiteralPath $claveEnv
    $pathCrudo = [string]$claveReg.GetValue('Path', '', 'DoNotExpandEnvironmentNames')
    $tipoPath  = try { $claveReg.GetValueKind('Path') } catch { [Microsoft.Win32.RegistryValueKind]::ExpandString }

    $yaEnPath = @($pathCrudo -split ';' | Where-Object { $_.Trim() -ne '' } |
                  ForEach-Object { [Environment]::ExpandEnvironmentVariables($_).Trim().TrimEnd('\') })

    $aAgregar = @()
    foreach ($d in @($binUsuario, $binBun)) {
        if ($yaEnPath -notcontains $d.TrimEnd('\')) { $aAgregar += $d }
    }

    if ($DryRun) {
        Info '[simulación] asegurar .local\bin y .bun\bin en el PATH'
    } elseif ($aAgregar.Count -eq 0) {
        Ok 'El PATH ya estaba configurado'
        Anotar 'ok' 'PATH' 'ya estaba'
    } else {
        $nuevo = if ($pathCrudo.Trim()) { $pathCrudo.TrimEnd(';') + ';' + ($aAgregar -join ';') } else { $aAgregar -join ';' }
        Set-ItemProperty -LiteralPath $claveEnv -Name 'Path' -Value $nuevo -Type $tipoPath -ErrorAction Stop
        Registrar "PATH usuario: añadido $($aAgregar -join ';')"
        # Escribir el registro a mano preserva REG_EXPAND_SZ, pero pierde el aviso
        # que sí manda [Environment]::SetEnvironmentVariable. Sin él, las terminales
        # nuevas no ven el PATH hasta cerrar sesión — que es justo lo que el cierre
        # le pide al empleado que haga.
        try {
            if (-not ('Win32.Difusion' -as [type])) {
                Add-Type -Namespace Win32 -Name Difusion -MemberDefinition @'
[DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam,
    string lParam, uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);
'@ -ErrorAction Stop
            }
            $sinUso = [UIntPtr]::Zero
            # HWND_BROADCAST = 0xffff, WM_SETTINGCHANGE = 0x1A, SMTO_ABORTIFHUNG = 2
            [void][Win32.Difusion]::SendMessageTimeout([IntPtr]0xffff, 0x1A, [UIntPtr]::Zero,
                                                       'Environment', 2, 5000, [ref]$sinUso)
            Registrar 'PATH: cambio difundido a las ventanas abiertas'
        } catch {
            Registrar "PATH: no pude difundir el cambio ($($_.Exception.Message))"
        }
        Refrescar-Path
        Ok 'PATH actualizado'
        Anotar 'ok' 'PATH' "añadido $($aAgregar -join ', ')"
    }
} 'Añadí a mano al PATH: %USERPROFILE%\.local\bin')

# ================================================= 13. VERIFICACIÓN FINAL ===
Titulo '13. Verificación final'

function Verificar($etiqueta, $cmd) {
    if (Hay $cmd) { Ok "$etiqueta responde"; Anotar 'ok' $etiqueta 'verificado'; return $true }
    Fallo "$etiqueta no responde"; Anotar 'error' $etiqueta 'no responde después de instalar'
    return $false
}

[void](Verificar 'Claude Code' 'claude')
[void](Verificar 'markitdown' 'markitdown')
[void](Verificar 'uv' 'uv')
[void](Verificar 'Git' 'git')
if (Quiere 'rtk')  { [void](Verificar 'rtk' 'rtk') }
if (Quiere 'node') { [void](Verificar 'Node.js' 'node') }

if (-not $DryRun) {
    if (HayPython) { Ok "Python responde ($(VersionPython))"; Anotar 'ok' 'Python' 'verificado' }
    else { Aviso 'Python no responde'; Anotar 'aviso' 'Python' 'no responde' }

    if (Quiere 'playwright') {
        if (HayPlaywright) { Ok 'Playwright responde'; Anotar 'ok' 'Playwright' 'verificado' }
        else { Aviso 'Playwright no está completo (falta el navegador)'; Anotar 'aviso' 'Playwright' 'sin navegador' }
    }
}

# Comprobación estructural del modo de permisos: que quedó escrito de verdad.
# Las dos claves son necesarias. Sin skipDangerousModePermissionPrompt, la
# primera sesión muestra un diálogo bloqueante y Claude Code sale si se declina.
if (-not $DryRun) {
    try {
        $sj = (LeerTexto $Ajustes) | ConvertFrom-Json -ErrorAction Stop
        $modo    = $sj.permissions.defaultMode
        $sinAviso = ($sj.skipDangerousModePermissionPrompt -eq $true)
        if ($modo -eq 'bypassPermissions' -and $sinAviso) {
            Ok 'Claude Code queda sin pedir permisos'
            Anotar 'ok' 'Permisos' 'bypassPermissions, sin diálogo inicial'
        } elseif ($modo -eq 'bypassPermissions') {
            Aviso 'Modo sin permisos activo, pero falta saltar el diálogo inicial'
            Nota  'La primera vez que abras Claude te va a pedir que aceptes el modo.'
            Anotar 'aviso' 'Permisos' 'falta skipDangerousModePermissionPrompt'
        } else {
            Aviso "El modo de permisos quedó en '$modo', no en bypassPermissions"
            Anotar 'aviso' 'Permisos' "quedó en '$modo'"
        }
    } catch {
        Aviso 'No pude verificar el modo de permisos'
        Anotar 'aviso' 'Permisos' 'no verificable'
    }
}

# Se vuelve a mirar el disco: la variable del diagnóstico es de ANTES de instalar.
if (AppEscritorio) { Ok 'Claude para escritorio presente' }
else { Aviso 'Claude para escritorio ausente'; Nota 'Descargala desde https://claude.com/download' }

# =================================================================== REPORTE =
function EscHtml($t) {
    if ($null -eq $t) { return '' }
    return ([string]$t).Replace('&','&amp;').Replace('<','&lt;').Replace('>','&gt;').Replace('"','&quot;')
}

if (-not $DryRun) {
    [void](Intentar 'No pude escribir el reporte' {
        $filas = ($script:Resultados | ForEach-Object {
            $marca = switch ($_.Estado) {
                'ok'    { '<span class="ok">&#10003; correcto</span>' }
                'aviso' { '<span class="aviso">! atención</span>' }
                default { '<span class="error">&#10007; error</span>' }
            }
            "<tr><td>$marca</td><td>$(EscHtml $_.Pieza)</td><td>$(EscHtml $_.Detalle)</td></tr>"
        }) -join "`r`n"

        if ($script:Fallos -gt 0) {
            $veredicto = "<div class=""banda mal"">Hubo $($script:Fallos) error(es). Mandale este reporte a Ricardo.</div>"
        } elseif ($script:Avisos -gt 0) {
            $veredicto = "<div class=""banda regular"">Terminado con $($script:Avisos) aviso(s). Se puede usar igual.</div>"
        } else {
            $veredicto = '<div class="banda bien">Todo correcto.</div>'
        }

        $bloqueDup = ''
        if ($Duplicados.Count -gt 0) {
            $items = ($Duplicados | ForEach-Object { "<li><code>$(EscHtml $_)</code></li>" }) -join ''
            $bloqueDup = "<div class=""caja""><b>Instalaciones duplicadas detectadas</b><br>El instalador no borró nada. Conviene revisarlas a mano:<ul>$items</ul></div>"
        }

        $logHref = 'file:///' + ($Log -replace '\\','/')

        $html = @"
<!DOCTYPE html>
<meta charset="utf-8"><title>Instalación - entorno Claude SUMA</title>
<style>
body{font:15px/1.6 -apple-system,"Segoe UI",Roboto,sans-serif;background:#f4f5f7;color:#16181d;margin:0}
.w{max-width:820px;margin:0 auto;padding:30px 20px 60px}
h1{font-size:23px;margin:0 0 4px}.sub{color:#5b6270;font-size:13px;margin:0 0 20px}
.banda{border-radius:8px;padding:12px 16px;margin:0 0 22px;font-weight:700}
.banda.bien{background:#e5f4ea;color:#1d6f42;border:1px solid #b7e0c6}
.banda.regular{background:#fdf4e0;color:#8a6400;border:1px solid #f0d99b}
.banda.mal{background:#fdeceb;color:#a5281c;border:1px solid #f2bdb8}
table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #dfe2e8;border-radius:8px;overflow:hidden}
th,td{text-align:left;padding:10px 12px;border-bottom:1px solid #eef0f4;font-size:14px}
th{background:#f7f8fa;font-size:12px;text-transform:uppercase;letter-spacing:.4px;color:#4a5160}
tr:last-child td{border-bottom:0}
.ok{color:#1d6f42;font-weight:700}.aviso{color:#b8860b;font-weight:700}.error{color:#c0392b;font-weight:700}
.caja{background:#fff;border:1px solid #dfe2e8;border-left:4px solid #16181d;border-radius:6px;padding:14px 16px;margin:20px 0;font-size:14px}
code{background:#eceef2;padding:1px 5px;border-radius:3px;font-size:12.5px;word-break:break-all}
</style><div class="w">
<h1>Instalación del entorno Claude</h1>
<p class="sub">SUMA Beneficios &middot; $(Get-Date -Format 'dd/MM/yyyy HH:mm') &middot; equipo <b>$(EscHtml $env:COMPUTERNAME)</b> &middot; usuario <b>$(EscHtml $env:USERNAME)</b><br>
$(EscHtml $VerWin) ($(EscHtml $Arq)) &middot; perfil $(EscHtml $Perfil) &middot; instalador $VersionInstalador</p>
$veredicto
<table><thead><tr><th>Estado</th><th>Pieza</th><th>Detalle</th></tr></thead><tbody>
$filas
</tbody></table>
$bloqueDup
<div class="caja"><b>Qué falta hacer a mano</b>
<ol>
<li><b>Entrar en Claude Code.</b> Abrí una terminal <b>nueva</b> (tecla Windows, escribí "Terminal"), escribí <code>claude</code> y seguí los pasos del navegador. Hace falta una cuenta de SUMA con suscripción activa.</li>
<li><b>Entrar en Google Drive.</b> Abrí la aplicación y entrá con la cuenta de SUMA. Cuando pregunte qué carpetas ver, elegí "Unidades compartidas".</li>
</ol></div>
<p class="sub">Log completo: <a href="$(EscHtml $logHref)"><code>$(EscHtml $Log)</code></a><br>
Instalador versión $VersionInstalador &middot; soporte: Ricardo Nieto</p>
</div>
"@
        EscribirTexto $Reporte $html
    })

    # ---------------------------------------------------- entrega del reporte
    # Tres capas, todas de mejor esfuerzo: nunca hacen fallar la instalación.
    $nombreReporte = "reporte-$env:COMPUTERNAME-$env:USERNAME-$sello.html"

    # 1) Copia al Escritorio, con nombre reconocible.
    try {
        $escritorio = [Environment]::GetFolderPath('Desktop')
        if ($escritorio) { Copy-Item -LiteralPath $Reporte -Destination (Join-Path $escritorio $nombreReporte) -Force -ErrorAction SilentlyContinue }
    } catch { }

    # 2) Si la unidad compartida está montada, dejar copia para Ricardo.
    if ($Origen) {
        try {
            $buzon = Join-Path (Split-Path -Parent $Origen) 'reportes'
            if (ExisteRuta $buzon) {
                Copy-Item -LiteralPath $Reporte -Destination (Join-Path $buzon $nombreReporte) -Force -ErrorAction Stop
                Copy-Item -LiteralPath $Log -Destination (Join-Path $buzon ($nombreReporte -replace '\.html$','.log')) -Force -ErrorAction SilentlyContinue

                # Una línea por máquina, para que Ricardo pueda consolidar.
                $piezas = [ordered]@{}
                foreach ($r in $script:Resultados) { $piezas[[string]$r.Pieza] = [string]$r.Estado }
                $resumen = [ordered]@{
                    fecha = (Get-Date -Format 's'); equipo = $env:COMPUTERNAME; usuario = $env:USERNAME
                    windows = $VerWin; perfil = $Perfil; version = $VersionInstalador
                    admin = $EsAdmin; fallos = $script:Fallos; avisos = $script:Avisos; piezas = $piezas
                }
                EscribirTexto (Join-Path $buzon "estado-$env:COMPUTERNAME-$env:USERNAME.json") ($resumen | ConvertTo-Json -Depth 5)
                Ok 'El reporte se le envió a Ricardo automáticamente'
            }
        } catch { Registrar "no pude copiar al buzón: $($_.Exception.Message)" }
    }
}

# ================================================================== CIERRE ===
Write-Host ''
Write-Host '==========================================================' -ForegroundColor White
Write-Host ''
if ($DryRun) {
    Write-Host '  Simulación terminada. No se modificó nada.' -ForegroundColor White
} elseif ($script:Fallos -eq 0) {
    Write-Host '  Listo. El entorno quedó instalado.' -ForegroundColor Green
} else {
    Write-Host "  Terminado, pero hubo $($script:Fallos) problema(s)." -ForegroundColor Yellow
    Write-Host '  Mirá el reporte que se abrió en el navegador.' -ForegroundColor Yellow
}

if (-not $DryRun) {
    Write-Host ''
    Write-Host '  TE FALTAN 2 COSAS, Y LAS TENÉS QUE HACER VOS' -ForegroundColor White
    Write-Host '  (el instalador no puede: piden tu usuario y contraseña)' -ForegroundColor Gray
    Write-Host ''
    Write-Host '  1) Entrar en Claude Code'
    Write-Host '     · Pulsá la tecla Windows, escribí "Terminal" y abrilo.'
    Write-Host '       Tiene que ser una ventana NUEVA: esta de acá no sirve,'
    Write-Host '       porque el PATH cambió mientras instalábamos.'
    Write-Host '     · Escribí:  claude   y pulsá Enter.'
    Write-Host '     · Se abre el navegador. Entrá con tu cuenta de SUMA y volvé'
    Write-Host '       a la ventana de la Terminal.'
    Write-Host ''
    Write-Host '  2) Entrar en Google Drive'
    Write-Host '     · Pulsá la tecla Windows, escribí "Google Drive" y abrilo.'
    Write-Host '     · Entrá con tu cuenta de SUMA.'
    Write-Host '     · Cuando pregunte qué carpetas ver, elegí "Unidades compartidas".'
    Write-Host ''
    Write-Host '  ¿Algo falló? Mandale a Ricardo estos dos archivos:' -ForegroundColor Gray
    Write-Host "     Reporte: $Reporte" -ForegroundColor Gray
    Write-Host "     Log:     $Log" -ForegroundColor Gray
    Write-Host '     (el reporte también quedó copiado en tu Escritorio)' -ForegroundColor Gray
}
Write-Host ''
Write-Host '==========================================================' -ForegroundColor White
Write-Host ''

if (-not $DryRun -and (ExisteRuta $Reporte)) {
    # OJO: Start-Process NO tiene -LiteralPath. Con él tiraba siempre, el catch
    # se lo tragaba, y el cierre igual decía 'mirá el reporte que se abrió'.
    try { Start-Process -FilePath $Reporte -ErrorAction Stop }
    catch { Info "Abrí el reporte a mano: $Reporte" }
}

Registrar "FIN fallos=$($script:Fallos) avisos=$($script:Avisos)"
RestaurarConsola
Read-Host '  Pulsá Enter para cerrar esta ventana'

# Código de salida real: INSTALAR.bat lo comprueba con %errorlevel%.
if ($DryRun) { exit 0 }
exit ([Math]::Min($script:Fallos, 255))
