@echo off
setlocal EnableExtensions
title Instalador de entorno Claude - SUMA Beneficios

rem ===========================================================================
rem  ESTE ARCHIVO SE GUARDA EN ASCII PURO Y CON FINALES DE LINEA CRLF.
rem  Nada de acentos aca: cmd.exe relee el .bat por lineas y con caracteres
rem  multibyte puede saltarse instrucciones. Toda la prosa en espanol (con
rem  acentos) vive en instalar-windows.ps1, que si esta en UTF-8 con BOM.
rem
rem  QUE HACE ESTE ARCHIVO
rem    1. Comprueba que el paquete que tenemos delante este completo.
rem    2. Decide si hace falta copiarlo a una carpeta local del equipo.
rem    3. Si hace falta, lo copia y desbloquea los archivos copiados.
rem    4. Ejecuta el instalador de verdad (instalar-windows.ps1).
rem
rem  SE PUEDE EJECUTAR DESDE CUALQUIER RUTA: Google Drive, un ZIP abierto con
rem  doble clic, el Escritorio, Descargas, un pendrive o una carpeta de red.
rem
rem  POR QUE SE COPIA A UNA CARPETA LOCAL ANTES DE INSTALAR
rem    - El paquete suele vivir en Google Drive, cuya ruta lleva corchetes
rem      "[ ]" (PowerShell los toma como comodines), es FAT32 virtual, y se
rem      puede desmontar a mitad de la instalacion.
rem    - Cuando se abre un ZIP con doble clic, Windows "ejecuta" el .bat desde
rem      una carpeta temporal que borra al cerrar la ventana del ZIP.
rem    En los dos casos el instalador se quedaria sin archivos a mitad de
rem    camino. Trabajando sobre una copia local eso no puede pasar.
rem
rem  POR QUE HAY UN ARCHIVO DE MARCA  (novedad v2.2: esto era un bug real)
rem    Hasta la v2.1 el destino de la copia era una ruta fija. Si el empleado
rem    ejecutaba el INSTALAR.bat que habia quedado DENTRO de esa carpeta
rem    destino, el script hacia "rd /s /q" sobre su propia carpeta: se borraba
rem    a si mismo y moria con "No pude copiar el instalador a tu equipo".
rem    Ahora, al copiar, se deja una marca que contiene la ruta de esa copia.
rem    Si al arrancar encontramos la marca y coincide con donde estamos, ya
rem    somos la copia local: se instala en el sitio y no se copia nada.
rem
rem  NO hace falta ejecutar como administrador. El instalador pide permiso
rem  una sola vez, al final, cuando le toca instalar Google Drive.
rem ===========================================================================

for %%I in ("%~dp0..") do set "ORIGEN=%%~fI"
set "RAIZ=%LOCALAPPDATA%\instalador-suma"
set "TRABAJO=%RAIZ%\trabajo"
set "MARCA=%ORIGEN%\copia-local.marca"
set "COPIALOG=%TEMP%\suma-copia.log"

echo.
echo   Instalador de entorno Claude - SUMA Beneficios
echo   ==============================================
echo.

rem --- 0. Sin PowerShell no hay nada que hacer -----------------------------
where powershell.exe >nul 2>&1
if errorlevel 1 goto :falta_powershell

rem --- 1. El paquete que tenemos delante, esta completo? -------------------
rem Se valida el ORIGEN antes de tocar nada. Asi, si falta una pieza, el
rem mensaje habla de la carpeta que abrio el empleado y no de una copia a
rem medias que el propio script acabaria de crear.
if not exist "%~dp0instalar-windows.ps1"          goto :paquete_incompleto
if not exist "%ORIGEN%\config\carpetas.txt"       goto :paquete_incompleto
if not exist "%ORIGEN%\config\settings-base.json" goto :paquete_incompleto

rem --- 2. Ya somos la copia local? -----------------------------------------
set "ENSITIO="

rem 2a. La marca dice para que carpeta se creo. Si coincide con donde estamos,
rem     somos la copia local. Si no coincide, alguien movio la carpeta de
rem     sitio: se ignora la marca y se vuelve a copiar.
if exist "%MARCA%" call :leer_marca

rem 2b. Cinturon y tirantes: aunque la marca falte o este corrupta, nunca hay
rem     que copiar una carpeta sobre si misma. Se comprueban el destino de
rem     esta version y el que usaban la 2.0 y la 2.1.
if /I "%ORIGEN%"=="%TRABAJO%"      set "ENSITIO=1"
if /I "%ORIGEN%"=="%RAIZ%\paquete" set "ENSITIO=1"

if defined ENSITIO goto :en_sitio

rem --- 3. Copiar el paquete al equipo --------------------------------------
echo   Preparando el instalador... (unos segundos)
echo.

if exist "%TRABAJO%" rd /s /q "%TRABAJO%" >nul 2>&1
md "%TRABAJO%" >nul 2>&1
if not exist "%TRABAJO%" goto :sin_permiso

rem robocopy es un .exe nativo: no expande comodines, aguanta espacios y
rem corchetes sin escapes, reintenta, y de paso fuerza a Google Drive a
rem materializar los archivos que estuvieran "solo en linea".
rem Sus codigos de salida menores que 8 son exito.
robocopy "%ORIGEN%" "%TRABAJO%" /E /R:2 /W:5 /NFL /NDL /NJH /NJS /NP >"%COPIALOG%" 2>&1
if errorlevel 8 goto :copia_fallo

if not exist "%TRABAJO%\windows\instalar-windows.ps1" goto :copia_fallo
if not exist "%TRABAJO%\config\carpetas.txt"          goto :copia_fallo
if not exist "%TRABAJO%\config\settings-base.json"    goto :copia_fallo

rem La marca lleva dentro la ruta de ESTA copia. Es lo que permite que, si
rem alguien ejecuta manana el INSTALAR.bat de aca dentro, se instale en el
rem sitio en vez de intentar borrarse a si mismo.
rem El ">" va delante a proposito: escrito como "echo %%TRABAJO%%>archivo",
rem cmd.exe se comeria el ultimo caracter de la ruta si fuera un digito.
>"%TRABAJO%\copia-local.marca" echo %TRABAJO%

rem Lo que baja de Drive o sale de un ZIP llega con "Mark of the Web": segun
rem la politica del equipo, PowerShell se niega a ejecutar un .ps1 marcado.
rem Se desbloquea la COPIA, nunca el original.
rem La ruta viaja por variable de entorno y no incrustada en el -Command:
rem asi no se rompe si el nombre de usuario lleva comillas o apostrofes.
set "SUMA_TRABAJO=%TRABAJO%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath $env:SUMA_TRABAJO -Recurse -File | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1
goto :ejecutar

:en_sitio
rem Ya estamos en una copia local: no se copia ni se borra nada.
set "TRABAJO=%ORIGEN%"
echo   Este equipo ya tiene el instalador copiado. Sigo desde aca.
echo.

:ejecutar
rem -Origen se le pasa al instalador para que sepa de donde salio el paquete
rem (lo deja escrito en el log y en el reporte final).
powershell -NoProfile -ExecutionPolicy Bypass -File "%TRABAJO%\windows\instalar-windows.ps1" -Origen "%ORIGEN%" %*
set "CODIGO=%errorlevel%"

if not "%CODIGO%"=="0" goto :hubo_errores
goto :fin

rem =========================================================== subrutinas ===
:leer_marca
rem set /p lee la primera linea del archivo y le quita el salto de linea.
set "MARCADO="
set /p MARCADO=<"%MARCA%"
if /I "%MARCADO%"=="%ORIGEN%" set "ENSITIO=1"
goto :eof

rem ============================================================== errores ===
:falta_powershell
echo   ================================================================
echo    ERROR: este equipo no tiene PowerShell disponible.
echo.
echo    Avisale a Ricardo o a IT de SUMA: es un componente de Windows y
echo    sin el no se puede instalar nada.
echo   ================================================================
echo.
pause
exit /b 1

:paquete_incompleto
echo   ================================================================
echo    ERROR: a esta carpeta le faltan archivos del instalador.
echo.
echo    Carpeta que abriste:
echo      %ORIGEN%
echo.
echo    Tienen que estar, como minimo:
echo      windows\instalar-windows.ps1
echo      config\carpetas.txt
echo      config\settings-base.json
echo.
echo    Que hacer: descargate la carpeta COMPLETA desde Google Drive
echo    (no solo este archivo suelto) y volve a intentarlo.
echo.
echo    Si la bajaste como ZIP: extraela primero con boton derecho ^>
echo    "Extraer todo". Ejecutar el .bat desde dentro del ZIP no sirve.
echo   ================================================================
echo.
pause
exit /b 1

:sin_permiso
echo   ================================================================
echo    No pude crear la carpeta de trabajo en tu equipo:
echo      %TRABAJO%
echo.
echo    Suele ser una politica de seguridad del equipo o un disco lleno.
echo    Avisale a Ricardo o a IT de SUMA.
echo   ================================================================
echo.
pause
exit /b 1

:copia_fallo
echo   ================================================================
echo    No pude copiar el instalador a tu equipo.
echo.
echo    Suele pasar cuando Google Drive esta desconectado o cuando los
echo    archivos todavia no se terminaron de descargar.
echo.
echo    Que hacer:
echo      1. Abri Google Drive y espera a que termine de sincronizar.
echo      2. Volve a intentarlo.
echo      3. Si sigue igual, avisale a Ricardo y mandale este archivo:
echo         %COPIALOG%
echo   ================================================================
echo.
pause
exit /b 1

:hubo_errores
echo.
echo   La instalacion termino con %CODIGO% problema(s).
echo   Revisa el reporte que se abrio en el navegador.
echo.
pause
exit /b %CODIGO%

:fin
endlocal
exit /b 0
