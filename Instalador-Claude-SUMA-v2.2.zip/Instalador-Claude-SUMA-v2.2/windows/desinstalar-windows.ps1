﻿#Requires -Version 5.0
# ============================================================================
#  Desinstalador del entorno Claude - SUMA Beneficios (Windows)
#  v2 - Ricardo Nieto / iA.Agency
#
#  No ejecutes este archivo directamente: usá DESINSTALAR.bat (doble clic).
#
#  Quita lo que instaló instalar-windows.ps1. NO borra las carpetas de
#  Documentos ni Google Drive: ahí está el trabajo de la persona.
#
#  Parámetros:
#    -Todo    quita todo sin preguntar pieza por pieza (pide confirmar una vez)
#
#  Mismas reglas de mantenimiento que el instalador: -LiteralPath siempre,
#  nunca un parámetro con el nombre de una variable de script, y nunca
#  informar "eliminado" sin haberlo comprobado.
# ============================================================================

[CmdletBinding()]
param([switch]$Todo)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$DirLog = Join-Path $env:LOCALAPPDATA 'instalador-suma'
[void][System.IO.Directory]::CreateDirectory($DirLog)
$Log = Join-Path $DirLog "desinstalacion-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"

function Registrar($t) {
    try { "{0}  {1}" -f (Get-Date -Format 'HH:mm:ss'), $t | Add-Content -LiteralPath $Log -Encoding UTF8 } catch { }
}
function Ok($t)    { Write-Host "  [OK] $t" -ForegroundColor Green;  Registrar "OK    $t" }
function Aviso($t) { Write-Host "  [!]  $t" -ForegroundColor Yellow; Registrar "AVISO $t" }
function Info($t)  { Write-Host "  .    $t" -ForegroundColor Gray;   Registrar "info  $t" }
function Nota($t)  { Write-Host "       $t" -ForegroundColor Gray;   Registrar "nota  $t" }

$EncodingPrevio = $null
try {
    $EncodingPrevio           = [Console]::OutputEncoding
    [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
    $OutputEncoding           = [Console]::OutputEncoding
} catch { }
function RestaurarConsola { if ($EncodingPrevio) { try { [Console]::OutputEncoding = $EncodingPrevio } catch { } } }

function ExisteRuta($ruta) {
    if ([string]::IsNullOrWhiteSpace($ruta)) { return $false }
    return (Test-Path -LiteralPath $ruta)
}
function LeerTexto($ruta) {
    if (-not (ExisteRuta $ruta)) { return $null }
    try { return [System.IO.File]::ReadAllText($ruta) } catch { return $null }
}
function Hay($cmd) {
    try { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) } catch { return $false }
}
function RutaDe($cmd) {
    try { return (Get-Command $cmd -ErrorAction SilentlyContinue | Select-Object -First 1 -ExpandProperty Source) } catch { return $null }
}
function Refrescar-Path {
    $partes = @(
        $env:Path,
        [Environment]::GetEnvironmentVariable('Path','Machine'),
        [Environment]::GetEnvironmentVariable('Path','User'),
        (Join-Path $env:USERPROFILE '.local\bin'),
        (Join-Path $env:USERPROFILE '.bun\bin')
    ) | Where-Object { $_ } | ForEach-Object { $_ -split ';' } | Where-Object { $_.Trim() -ne '' }
    $vistas = New-Object System.Collections.Generic.HashSet[string]([StringComparer]::OrdinalIgnoreCase)
    $env:Path = (($partes | Where-Object { $vistas.Add($_.Trim().TrimEnd('\')) }) -join ';')
}
Refrescar-Path

function CorrerNativo {
    param([string]$Exe, [string[]]$Argumentos = @(), [string]$Que = '')
    Registrar "CMD $Exe $($Argumentos -join ' ')"
    $idTmp = [guid]::NewGuid().ToString('N')
    $fSal  = Join-Path $env:TEMP "suma-out-$idTmp.txt"
    $fErr  = Join-Path $env:TEMP "suma-err-$idTmp.txt"
    $codigo = $null
    # Start-Process con redirecciones necesita un .exe: npm es npm.cmd, y
    # claude instalado por npm deja claude.cmd y claude.ps1.
    $ruta = $Exe
    try {
        $g = Get-Command $Exe -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($g -and $g.Source) { $ruta = $g.Source }
    } catch { }
    if ($ruta -match '\.(cmd|bat)$') {
        $Argumentos = @('/c', $ruta) + $Argumentos
        $ruta = $env:ComSpec
    } elseif ($ruta -match '\.ps1$') {
        $Argumentos = @('-NoProfile','-ExecutionPolicy','Bypass','-File', $ruta) + $Argumentos
        $ruta = 'powershell.exe'
    }
    try {
        $sp = @{
            FilePath = $ruta; NoNewWindow = $true; Wait = $true; PassThru = $true
            RedirectStandardOutput = $fSal; RedirectStandardError = $fErr; ErrorAction = 'Stop'
        }
        if ($Argumentos.Count -gt 0) { $sp['ArgumentList'] = $Argumentos }
        $p = Start-Process @sp
        $codigo = $p.ExitCode
    } catch {
        Registrar "ERROR al lanzar $Exe : $($_.Exception.Message)"
    } finally {
        foreach ($f in @($fSal, $fErr)) {
            if (ExisteRuta $f) {
                $t = LeerTexto $f
                if ($t -and $t.Trim()) { try { Add-Content -LiteralPath $Log -Value $t -Encoding UTF8 } catch { } }
                Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue
            }
        }
    }
    Registrar "exit=$codigo ($Que)"
    return ($codigo -eq 0)
}

trap {
    Registrar "EXCEPCIÓN NO CONTROLADA: $($_.Exception.Message)"
    Registrar "  traza: $($_.ScriptStackTrace)"
    Write-Host ''
    Write-Host '  [X]  Algo salió mal y el desinstalador tuvo que parar.' -ForegroundColor Red
    Write-Host "       Log: $Log" -ForegroundColor Red
    Write-Host ''
    RestaurarConsola
    Read-Host '  Enter para cerrar'
    exit 1
}

$Ajustes   = Join-Path $env:USERPROFILE '.claude\settings.json'
$dirClaude = Join-Path $env:USERPROFILE '.claude'

Write-Host ''
Write-Host 'Desinstalador del entorno Claude - SUMA Beneficios' -ForegroundColor White
Write-Host ''
Write-Host 'Esto quita las herramientas que instaló el instalador.'
Write-Host ''
Write-Host 'NO se toca:' -ForegroundColor White
Write-Host '  · tus carpetas y archivos de Documentos'
Write-Host '  · Google Drive ni nada sincronizado'
Write-Host ''
Write-Host 'Al final te voy a preguntar si querés quitar también la configuración'
Write-Host 'de Claude (ajustes, plugins e historial). Si decís que sí, vas a tener'
Write-Host 'que volver a iniciar sesión en Claude Code. No se borra: se guarda una'
Write-Host 'copia que se puede recuperar.'
Write-Host ''

if ($Todo) {
    # -Todo no pregunta pieza por pieza: al menos que confirme una vez, y a
    # propósito, no con un Enter distraído.
    Write-Host '  Modo -Todo: se va a quitar TODO sin preguntar pieza por pieza.' -ForegroundColor Yellow
    Write-Host ''
    $conf = Read-Host '  Escribí BORRAR (en mayúsculas) y pulsá Enter para confirmar'
    if ($conf -cne 'BORRAR') {
        Write-Host ''
        Write-Host '  Cancelado. No se quitó nada.' -ForegroundColor White
        RestaurarConsola
        Read-Host '  Enter para cerrar'
        exit 0
    }
} else {
    $r = Read-Host '  Pulsá Enter para continuar, o escribí no y Enter para salir'
    if ($r.Trim() -match '^(n|no)$') {
        Write-Host ''
        Write-Host '  Listo, no se quitó nada.' -ForegroundColor White
        RestaurarConsola
        Read-Host '  Enter para cerrar'
        exit 0
    }
}

function Preguntar($que) {
    if ($Todo) { return $true }
    $r = Read-Host "  ¿Quitar $que? [s/N]"
    return ($r -match '^[sSyY]')
}

Write-Host ''
Write-Host 'Quitando...' -ForegroundColor White
Write-Host ''

# ------------------------------------------------------------------- gstack
$gstack = Join-Path $env:USERPROFILE '.claude\skills\gstack'
if (ExisteRuta $gstack) {
    if (Preguntar 'gstack (~1 GB)') {
        try {
            Remove-Item -LiteralPath $gstack -Recurse -Force -ErrorAction Stop
            if (ExisteRuta $gstack) { Aviso 'gstack no se pudo borrar del todo' } else { Ok 'gstack eliminado' }
        } catch { Aviso "no pude eliminar gstack: $($_.Exception.Message)" }
    } else { Info 'gstack: se deja' }
} else { Info 'gstack no estaba' }

# ---------------------------------------------------------------------- rtk
$rtkQuitado = $false
if (Hay rtk) {
    $rutaRtk = RutaDe 'rtk'
    if (Preguntar "rtk ($rutaRtk)") {
        # Borramos la ruta REAL que resuelve el PATH, no una ruta supuesta:
        # rtk puede estar en .local\bin o en AppData\Local\Programs\rtk.
        try { Remove-Item -LiteralPath $rutaRtk -Force -ErrorAction SilentlyContinue } catch { }
        try { Remove-Item -LiteralPath (Join-Path $env:USERPROFILE '.rtk') -Recurse -Force -ErrorAction SilentlyContinue } catch { }
        Refrescar-Path
        if (Hay rtk) {
            Aviso "rtk sigue respondiendo desde $(RutaDe 'rtk')"
            Nota 'Quitalo a mano desde esa ruta.'
        } else { Ok 'rtk eliminado'; $rtkQuitado = $true }
    } else { Info 'rtk: se deja' }
} else { Info 'rtk no estaba' }

# Si se quitó rtk hay que sacar también su enganche de settings.json. Si no,
# Claude Code intentaría ejecutar 'rtk hook claude' en CADA comando de Bash
# y fallaría en todos.
if ($rtkQuitado -and (ExisteRuta $Ajustes)) {
    try {
        $j = (LeerTexto $Ajustes) | ConvertFrom-Json -ErrorAction Stop
        if ($j.PSObject.Properties.Name -contains 'hooks' -and $j.hooks -and
            $j.hooks.PSObject.Properties.Name -contains 'PreToolUse') {
            Copy-Item -LiteralPath $Ajustes -Destination "$Ajustes.respaldo-rtk" -Force -ErrorAction SilentlyContinue
            $j.hooks.PSObject.Properties.Remove('PreToolUse')
            if (-not $j.hooks.PSObject.Properties.Name) { $j.PSObject.Properties.Remove('hooks') }
            [System.IO.File]::WriteAllText($Ajustes, ($j | ConvertTo-Json -Depth 20),
                                           (New-Object System.Text.UTF8Encoding($false)))
            Ok 'se quitó el enganche de rtk de la configuración de Claude'
        }
    } catch {
        Aviso 'No pude limpiar el enganche de rtk en settings.json'
        Nota  "Revisalo a mano: $Ajustes (quitá el bloque hooks > PreToolUse)"
    }
}

# --------------------------------------------------------------- markitdown
if (Hay markitdown) {
    if (Preguntar 'markitdown') {
        if (Hay uv) {
            [void](CorrerNativo 'uv' @('tool','uninstall','markitdown') 'uv tool uninstall markitdown')
            Refrescar-Path
            if (Hay markitdown) {
                Aviso 'markitdown sigue respondiendo'
                Nota  'Quitalo a mano con: uv tool uninstall markitdown'
            } else { Ok 'markitdown eliminado' }
        } else {
            Aviso 'No encuentro uv: no puedo desinstalar markitdown automáticamente'
            Nota  'Instalá uv o borrá a mano la carpeta de la herramienta.'
        }
    } else { Info 'markitdown: se deja' }
} else { Info 'markitdown no estaba' }

# -------------------------------------------------------------- superpowers
# El estado real del plugin vive acá, no en settings.json.
$ArchivoPlugins = Join-Path $env:USERPROFILE '.claude\plugins\installed_plugins.json'
function HaySuperpowers {
    $t = LeerTexto $ArchivoPlugins
    return ([bool]($t -and $t -match 'superpowers@'))
}
if (HaySuperpowers) {
    if (Preguntar 'el plugin superpowers') {
        if (Hay claude) {
            [void](CorrerNativo 'claude' @('plugin','uninstall','superpowers@claude-plugins-official') 'plugin uninstall')
            if (HaySuperpowers) { Aviso 'superpowers sigue instalado: quitalo desde Claude Code' }
            else { Ok 'superpowers eliminado' }
        } else {
            Aviso 'No encuentro el comando claude: no puedo quitar el plugin'
            Nota  'Se quita solo si borrás la configuración de Claude (última pregunta).'
        }
    } else { Info 'superpowers: se deja' }
} else { Info 'superpowers no estaba' }

# ----------------------------------------------------- Claude para escritorio
$appClaude = @(
    (Join-Path $env:LOCALAPPDATA 'AnthropicClaude'),
    (Join-Path $env:LOCALAPPDATA 'Programs\Claude')
) | Where-Object { ExisteRuta $_ } | Select-Object -First 1

$hayAppx = $false
try { $hayAppx = [bool](Get-AppxPackage -Name 'Claude' -ErrorAction SilentlyContinue) } catch { }

if ($appClaude -or $hayAppx) {
    if (Preguntar 'la aplicación Claude para escritorio') {
        $listo = $false
        # Si vino de winget/Store es un paquete MSIX.
        if ($hayAppx -and (Hay winget)) {
            $listo = CorrerNativo 'winget' @('uninstall','--id','Anthropic.Claude','-e','--silent',
                                             '--accept-source-agreements','--disable-interactivity') 'winget uninstall Claude'
        }
        if (-not $listo -and $appClaude) {
            $des = $null
            try { $des = Get-ChildItem -LiteralPath $appClaude -Filter 'Uninstall*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1 } catch { }
            $upd = Join-Path $appClaude 'Update.exe'
            try {
                if ($des) {
                    Start-Process -FilePath $des.FullName -Wait -ErrorAction Stop
                    $listo = $true
                } elseif (ExisteRuta $upd) {
                    # Instalador tipo Squirrel: no deja Uninstall.exe, el
                    # desinstalador es Update.exe --uninstall.
                    Start-Process -FilePath $upd -ArgumentList '--uninstall' -Wait -ErrorAction Stop
                    $listo = $true
                }
            } catch { Registrar "ERROR desinstalador app: $($_.Exception.Message)" }
        }
        if ($listo) { Ok 'se lanzó el desinstalador de Claude para escritorio' }
        else {
            Aviso 'No encontré su desinstalador'
            Nota  'Quitala desde Configuración > Aplicaciones > Aplicaciones instaladas > Claude'
        }
    } else { Info 'Claude para escritorio: se deja' }
} else { Info 'Claude para escritorio no estaba' }

# -------------------------------------------------------------- Claude Code
if (Hay claude) {
    $rutaClaude = RutaDe 'claude'
    if (Preguntar "Claude Code, el de la terminal ($rutaClaude)") {
        try { Remove-Item -LiteralPath $rutaClaude -Force -ErrorAction SilentlyContinue } catch { }
        # El instalador nativo deja claude.exe; el de npm deja .cmd + .ps1 +
        # un script sin extensión. Barremos los hermanos del mismo nombre.
        try {
            $carpeta = Split-Path -Parent $rutaClaude
            Get-ChildItem -LiteralPath $carpeta -Filter 'claude.*' -ErrorAction SilentlyContinue |
                Remove-Item -Force -ErrorAction SilentlyContinue
        } catch { }
        Refrescar-Path
        if (Hay claude) {
            Aviso "Claude Code sigue respondiendo desde $(RutaDe 'claude')"
            Nota  'Quitalo a mano desde esa ruta.'
        } else {
            Ok 'Claude Code eliminado'
            Nota 'La configuración y el historial siguen en %USERPROFILE%\.claude'
        }
    } else { Info 'Claude Code: se deja' }
} else { Info 'Claude Code no estaba' }

# ------------------------------------------------------------ configuración
if (ExisteRuta $dirClaude) {
    if (Preguntar 'la configuración de Claude (.claude: ajustes, plugins e historial)') {
        $resp = Join-Path $env:USERPROFILE "claude-respaldo-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        try {
            Move-Item -LiteralPath $dirClaude -Destination $resp -ErrorAction Stop
            Ok 'configuración movida (no se borró)'
            Nota "Copia en: $resp"
            Nota 'Vas a tener que volver a iniciar sesión en Claude Code.'
        } catch { Aviso "no pude mover .claude: $($_.Exception.Message)" }
    } else { Info 'configuración: se deja' }
}

Write-Host ''
Write-Host 'Listo.' -ForegroundColor White
Write-Host ''
Write-Host 'Lo que NO se tocó, y hay que quitar a mano si hace falta:' -ForegroundColor White
Write-Host '  · Google Drive - Configuración > Aplicaciones > Google Drive > Desinstalar'
Write-Host '  · Las carpetas de Documentos - son tuyas, con tu trabajo dentro'
Write-Host '  · uv, bun, Git, Node.js, ripgrep - otras cosas pueden estar usándolos'
Write-Host '  · La entrada .local\bin del PATH - inofensiva, pero se puede borrar'
Write-Host ''
Write-Host "Log: $Log"
Write-Host ''
RestaurarConsola
Read-Host '  Pulsá Enter para cerrar'
exit 0
