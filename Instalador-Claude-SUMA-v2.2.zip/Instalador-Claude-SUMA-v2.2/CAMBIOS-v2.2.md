# Instalador entorno Claude — SUMA Beneficios · v2.2.0

Cambios respecto de la v2.1.0. Ninguno toca el flujo que ve el empleado salvo
donde se indica.

---

## 1. La v2.1.0 no arrancaba. Nada. (crítico)

`instalar-windows.ps1`, línea 1054:

```powershell
Nota "Ejecutalo a mano: bash -lc \"cd '$rutaUnix' && ./setup --host claude\""
```

En PowerShell las comillas dentro de una cadena se escapan con acento grave
(`` `" ``) o duplicándolas (`""`). La barra invertida **no escapa nada**: parte
la cadena ahí mismo y lo que sigue queda como código suelto, con lo que `&&`
—que en PowerShell 5.1 no es un operador válido— produce:

```
El token '&&' no es un separador de instrucciones válido en esta versión.
```

Es un **error de sintaxis**, no de ejecución: PowerShell parsea el archivo
entero antes de ejecutar la primera línea. El instalador no llegaba a
arrancar en ningún equipo, viniera de donde viniera.

Comprobado ejecutando la v2.1.0 tal cual: `exit=1`, cero líneas de log.

**Arreglado** usando `` `" `` y con un comentario al lado explicando por qué.

---

## 2. El lanzador se borraba a sí mismo

`INSTALAR.bat` copiaba el paquete a una ruta fija
(`%LOCALAPPDATA%\instalador-suma\paquete`) y, antes de copiar, hacía
`rd /s /q` sobre ella.

Si el empleado ejecutaba el `INSTALAR.bat` que había quedado **dentro** de esa
carpeta —cosa que pasa en cuanto alguien abre la copia local en vez del
original— el script borraba su propia carpeta, no encontraba nada que copiar y
moría con «No pude copiar el instalador a tu equipo». El mensaje culpaba a
Google Drive, que no tenía nada que ver.

**Arreglado.** Ahora el lanzador reconoce si ya está sobre una copia local y,
en ese caso, instala en el sitio sin copiar ni borrar nada:

- Al copiar deja un archivo `copia-local.marca` que **contiene la ruta de esa
  copia**. Si al arrancar la marca coincide con dónde estamos, somos la copia.
  Si no coincide (alguien movió la carpeta), se ignora y se copia de nuevo.
- Además, comprobación directa contra el destino actual y contra el de las
  versiones 2.0/2.1, por si la marca falta o está corrupta.
- El directorio de trabajo pasa a llamarse `trabajo` (antes `paquete`), para
  no chocar con copias viejas que anden dando vueltas.

Probado en cuatro sitios: Escritorio, la propia copia local, la carpeta
`paquete` heredada, y una ruta con corchetes `[ ARG SUMA BENEFICIOS ]` como la
de Google Drive. Los cuatro arrancan y ninguno se autodestruye.

---

## 3. Sin winget, el instalador se caía en vez de avisar

El aviso de winget (línea 308) llamaba a `Anotar`, que se definía 140 líneas
más abajo. PowerShell ejecuta las definiciones en orden: hasta que su línea no
se ejecuta, la función no existe. Con `$ErrorActionPreference = 'Stop'` eso
mata el script.

O sea: **en todo equipo sin winget el instalador moría entero**, y sin decir
por qué. Justo los equipos que más ayuda necesitaban.

**Arreglado** en dos partes:

- `$script:Resultados` y `Anotar` se definen ahora antes de su primer uso.
- Nueva función `RepararWinget`: en vez de rendirse, intenta habilitarlo.
  1. Volver a registrar el paquete que ya está en el equipo (local,
     instantáneo, sin permisos). Cubre el caso habitual: perfil nuevo o imagen
     corporativa con «Instalador de aplicaciones» presente pero sin registrar.
  2. Si no, descargarlo de `https://aka.ms/getwinget` e instalarlo.

  Si los dos fallan, avisa y sigue con el resto, como antes.

Se añadió la **regla 5** a la cabecera de mantenimiento del `.ps1`: nunca
llamar a una función definida más abajo.

---

## 4. Python instalado que se informaba como ausente

`HayPython` miraba **solo la primera** resolución de `python`
(`Select-Object -First 1`) y, si esa era el stub de la Microsoft Store, se
rendía.

Pero el orden del PATH no es de fiar: `Refrescar-Path` antepone el PATH del
proceso (que puede venir viejo de la ventana que lanzó el instalador) al del
registro. En este equipo, con **Python 3.13.15 correctamente instalado**, el
diagnóstico decía `Python - no instalado` y lo reinstalaba al pedo.

**Arreglado** con `BuscarPython`, que mira todas las resoluciones (`-All`, no
solo la primera) y además las carpetas donde el instalador oficial deja
Python. El caché se refresca después de instalar, que si no un Python recién
puesto seguía dando «no está».

También se añadió `%LOCALAPPDATA%\Microsoft\WindowsApps` a `Refrescar-Path`:
es donde vive winget, y sin esa entrada `RepararWinget` hacía el trabajo y
luego informaba de que había fracasado.

---

## 5. Robustez del lanzador

- Valida que el paquete esté completo **antes** de tocar nada, y el mensaje de
  error nombra la carpeta que abrió el empleado, no una copia a medias.
- Mensaje propio para ZIP sin extraer, que es de donde salen la mitad de los
  «me faltan archivos».
- Comprueba que exista PowerShell.
- Distingue «no pude crear la carpeta de trabajo» (política/disco) de «no pude
  copiar» (Drive), que antes eran el mismo mensaje.
- Desbloquea los archivos copiados (Mark of the Web). Lo que baja de Drive o
  sale de un ZIP llega marcado y, según la política del equipo, PowerShell se
  niega a ejecutar un `.ps1` así. Se desbloquea **la copia**, nunca el original.
- La ruta viaja por variable de entorno, no incrustada en el `-Command`: así no
  se rompe si el nombre de usuario lleva apóstrofes.

---

## Lo que NO cambió

- **Google Drive se sigue instalando al final** (paso 11). Los pasos 12 y 13
  son PATH y verificación: no instalan nada. Ya estaba bien.
- La validación «si está, no lo toco; si falta, lo instalo» ya existía y
  funciona: es el paso 1 (diagnóstico) más los `Necesita` de cada bloque.
- `desinstalar-windows.ps1` y `DESINSTALAR.bat`: sin cambios, verificados sanos.
- `config/carpetas.txt` y `config/settings-base.json`: sin cambios.

---

## Antes de subirlo a Drive

Verificado en este paquete:

| Comprobación | Estado |
|---|---|
| `instalar-windows.ps1` — sintaxis y BOM UTF-8 | OK |
| `desinstalar-windows.ps1` — sintaxis y BOM UTF-8 | OK |
| `INSTALAR.bat` / `DESINSTALAR.bat` — ASCII puro, CRLF | OK |
| `settings-base.json` — JSON válido | OK |
| `carpetas.txt` — UTF-8, 7 carpetas, acentos intactos | OK |
| Versión coherente en `.ps1` y en la guía | 2.2.0 |
| Arranque real desde 4 rutas distintas | OK |

Falta una prueba que **no** se pudo hacer acá: una instalación completa en un
equipo limpio (este ya tenía casi todo). Conviene probarla en una máquina
virgen antes de repartirla.
